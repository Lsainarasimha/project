<?php
	
	if (isset($_GET['addtocart']))
	{
		session_start();
		addToCart();
		
	}
	if (isset($_GET['removefromcart']))
	{
		session_start();
		removeFromCart();
		
	}
	if (isset($_GET['rebuild']))
	{
		session_start();
		reBuild();
		
	}
	if (isset($_POST['checkusername']))
	{
		username();
	}
	if (isset($_POST['save_review']))
	{
		saveReview();
	}
	function addToCart()
	{
		if(isset($_SESSION['cart-items']))
		{
			if (isset($_SESSION['cart-items'][''.$_GET['isbn'].'']))
			{
				$_SESSION['cart-items'][''.$_GET['isbn'].''] = $_SESSION['cart-items'][$_GET['isbn']] + 1;
			}
			else 
			{
				$_SESSION['cart-items']["".$_GET['isbn'].""] = 1;
			}
		}
		else 
			$_SESSION['cart-items']["".$_GET['isbn'].""] = 1;
	}
	function removeFromCart()
	{
		if (isset($_SESSION['cart-items'][''.$_GET['isbn'].'']))
		{
			unset($_SESSION['cart-items'][''.$_GET['isbn'].'']);
		}
	}
	function reBuild()
	{
		if (isset($_SESSION['cart-items'][''.$_GET['isbn'].'']))
		{
			$_SESSION['cart-items'][''.$_GET['isbn'].''] = $_GET['quantity'];
		}
	}
	function username()
	{
		require_once("../common/Database.php");
		$db = new Database;
		$db_connect = $db->connect();
		$username = $_POST['username'];
		$sql = "SELECT * FROM customer WHERE username = '".$username."'";
		$users = $db->query($db_connect, $sql);
		if ($users->num_rows > 0){
			echo json_encode(0);
		}
		else{
			echo json_encode(1);
		}
	}
	function saveReview()
	{
		$name = $_POST['name'];
		$review = $_POST['review'];
		$isbn = $_POST['isbn'];
		require_once("../common/Database.php");
		$db = new Database;
		$db_connect = $db->connect();
		$sql = "INSERT INTO bookreview (isbn,name,review) VALUES ('".$_POST['isbn']."','".$_POST['name']."','".$_POST['review']."')";
		$users = $db->query($db_connect, $sql);
		header("Location:../catalog/details.php?book_id=".$isbn."");
	}
?>
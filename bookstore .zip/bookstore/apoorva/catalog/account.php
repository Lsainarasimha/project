<?php include "../catalog/header.php"; ?>
<div class="container">
	<h2>My Account</h2>
	<div class="row">
	<?php
		if (isset($_POST['update-details']))
		{
		    $firstname       = $_POST['firstname'];
		    $lastname        = $_POST['lastname'];
		    $address         = $_POST['address'];
		    $city            = $_POST['city'];
		    $state           = $_POST['state'];
		    $zip             = $_POST['zip'];
		    $card_type       = $_POST['card_type'];
		    $card_number     = $_POST['card_number'];
		    $expiration_date = $_POST['expiration_date'];
		    $sql = "UPDATE customer SET firstname = '".$firstname."', lastname = '".$lastname."', street = '".$address."', city = '".$city."', state = '".$state."', zip = '".$zip."', cctype = '".$card_type."', ccno = '".$card_number."', ccexpdt = '".$expiration_date."' WHERE username='".$_SESSION['customer_username']."'";
		    $result = $db->query($db_connect, $sql);
		    echo "<div class='text-success'><h5>Details Updated Successfully</h5></div>";
		}
		else if (isset($_POST['password-change']))
	    {
	        $password        = $_POST['password'];
	        $sql = "UPDATE customer SET pin = '".md5($password)."' WHERE username='".$_SESSION['customer_username']."'";
	        $result = $db->query($db_connect, $sql);
	        echo "<div class='text-success'><h5>Password ChangedSuccessfully</h5></div>";
	    }
	    else if (isset($_GET['checkout']))
	    {
	    	$sub_total = 0;
			foreach ($_SESSION['cart-items'] as $key => $value) {
				$sql = "SELECT * FROM book WHERE isbn = '".$key."'";
				$books = $db->query($db_connect, $sql);
				$row = mysqli_fetch_assoc($books);
				$sub_total += $value * $row['price'];
			}

			$sql = "INSERT INTO custorder (dayofmonth,monthoforder,yearoforder,timeoforder,amount,username) VALUES ('".date("d")."','".date("m")."','".date("Y")."','".date("H:i:s")."','".$sub_total."','".$_SESSION['customer_username']."')";
    		$result = $db->query($db_connect, $sql);
    		$order_id = mysqli_insert_id($db_connect);
    		foreach ($_SESSION['cart-items'] as $key => $value) {
    			$sql = "SELECT * FROM book WHERE isbn = '".$key."'";
    			$books = $db->query($db_connect, $sql);
    			$row = mysqli_fetch_assoc($books);
    			$sub_total += $value * $row['price'];
				$sql = "INSERT INTO order_quantity (dayofmonth,monthoforder,yearoforder,timeoforder,price,isbn,quantity,order_id) VALUES ('".date("d")."','".date("m")."','".date("Y")."','".date("H:i:s")."','".$row['price']."','".$row['isbn']."','".$value."','".$order_id."')";
	    		$result = $db->query($db_connect, $sql);
	    		unset($_SESSION['cart-items']);
    		}
    		$_SESSION['message'] = "Your Order Placed Successfully.You can check your order Details in orders tab"; 
    		header("Location: ../catalog/account.php");
	    }
	    else if (isset($_SESSION['message']))
		{
			echo "<div class=\"text-success\"><h5>".$_SESSION['message']."</h5></div>";
			unset($_SESSION['message']);
		}
		$sql = "SELECT * FROM customer WHERE username = '".$_SESSION['customer_username']."'";
		$result = $db->query($db_connect, $sql);
		$details = mysqli_fetch_assoc($result);		
	?>
		<!-- Nav tabs -->
		 <ul class="nav nav-tabs" role="tablist">
		   <li role="presentation" class="active"><a href="#details" aria-controls="details" role="tab" data-toggle="tab">Details</a></li>
		   <li role="presentation"><a href="#password" aria-controls="password" role="tab" data-toggle="tab">Change Password</a></li>
		   <li role="presentation"><a href="#update" aria-controls="update" role="tab" data-toggle="tab">Update Details</a></li>
		   <li role="presentation"><a href="#orders" aria-controls="orders" role="tab" data-toggle="tab">Orders</a></li>
		 </ul>

		 <!-- Tab panes -->
		 <div class="tab-content">
		   <div role="tabpanel" class="tab-pane fade in active" id="details">
		   		<br/>
	   		    <div class="table-responsive"> 
	   		    	<table class="table table-bordered table-striped"> 
	   		    		<colgroup> 
	   		    			<col class="col-xs-2"> 
	   		    			<col class="col-xs-5"> 
	   		    		</colgroup> 
	   					<tbody> 
	   						<tr> 
	   							<th scope="row"> <code>First Name</code> </th> 
	   							<td><?php echo $details['firstname']; ?></td> 
	   						</tr> 
	   						<tr> 
	   							<th scope="row"> <code>Last Name</code> </th> 
	   							<td><?php echo $details['lastname']; ?></td> 
	   						</tr>
	   						<tr> 
	   							<th scope="row"> <code>Username</code> </th> 
	   							<td><?php echo $details['username']; ?></td> 
	   						</tr>
	   						<tr> 
	   							<th scope="row"> <code>Address</code> </th> 
	   							<td><?php echo $details['street']; ?></td> 
	   						</tr> 
	   						<tr> 
	   							<th scope="row"> <code>City</code> </th> 
	   							<td><?php echo $details['city']; ?></td> 
	   						</tr>
	   						<tr> 
	   							<th scope="row"> <code>State</code> </th> 
	   							<td><?php echo $details['state']; ?></td> 
	   						</tr>
	   						<tr> 
	   							<th scope="row"> <code>Zip</code> </th> 
	   							<td><?php echo $details['zip']; ?></td> 
	   						</tr>
	   						<tr>
	   							<td class="text-center" colspan="2"><h3>Credit Card Details</h3></td>
	   						</tr>
	   						<tr> 
	   							<th scope="row"> <code>Credit Card</code> </th> 
	   							<td><?php echo $details['cctype']; ?></td> 
	   						</tr> 
	   						<tr> 
	   							<th scope="row"> <code>Credit Card Number</code> </th> 
	   							<td><?php echo $details['ccno']; ?></td> 
	   						</tr>
	   						<tr> 
	   							<th scope="row"> <code>Expiry Date</code> </th> 
	   							<td><?php echo $details['ccexpdt']; ?></td> 
	   						</tr>
	   					</tbody> 
	   		    	</table> 
	   		    </div>
		   </div>
		   <div role="tabpanel" class="tab-pane fade" id="password">
		   		<br/>
		   		<form class="form-horizontal" method="POST">
		   		    <div class="form-group">
		   		        <label for="inputPassword3" class="col-sm-2 control-label">Password</label>
		   		        <div class="col-sm-10">
		   		            <input type="password" class="form-control" id="password" name="password" placeholder="Password">
		   		        </div>
		   		    </div>
		   		    <div class="form-group">
		   		        <label for="inputPassword3" class="col-sm-2 control-label">Repeat Password</label>
		   		        <div class="col-sm-10">
		   		            <input type="password" class="form-control" id="repeat-password" name="repeat-password" placeholder="Repeat Password">
		   		        </div>
		   		    </div>
		   		    <div class="form-group">
		   		        <div class="col-sm-offset-2 col-sm-10">
		   		            <button type="button" class="btn btn-success pull-right">Cancel</button>
		   		            <button type="submit" name="password-change" class="btn btn-danger pull-right" style="margin-right:5px;">Change Password</button>
		   		        </div>
		   		    </div>
		   		</form>
		   </div>
		   <div role="tabpanel" class="tab-pane fade" id="update">
		   <br/>
		   		<form class="form-horizontal" method="POST">
		   		    <div class="form-group">
		   		        <label for="inputEmail3" class="col-sm-2 control-label">First Name</label>
		   		        <div class="col-sm-10">
		   		            <input type="text" class="form-control" id="firstname" name="firstname" value="<?php echo $details['firstname']; ?>" placeholder="First Name">
		   		        </div>
		   		    </div>
		   		    <div class="form-group">
		   		        <label for="inputPassword3" class="col-sm-2 control-label">Last Name</label>
		   		        <div class="col-sm-10">
		   		            <input type="text" class="form-control" id="lastname" name="lastname" value="<?php echo $details['lastname']; ?>" placeholder="Last Name">
		   		        </div>
		   		    </div>
		   		    <div class="form-group">
		   		        <label for="inputPassword3" class="col-sm-2 control-label">Address</label>
		   		        <div class="col-sm-10">
		   		            <input type="text" class="form-control" id="address" name="address" value="<?php echo $details['street']; ?>" placeholder="Address">
		   		        </div>
		   		    </div>
		   		    <div class="form-group">
		   		        <label for="inputPassword3" class="col-sm-2 control-label">city</label>
		   		        <div class="col-sm-10">
		   		            <input type="text" class="form-control" id="city" name="city" value="<?php echo $details['city']; ?>" placeholder="city">
		   		        </div>
		   		    </div>
		   		    <div class="form-group">
		   		        <label for="inputPassword3" class="col-sm-2 control-label">state</label>
		   		        <div class="col-sm-10">
		   		            <select id="state" name="state" class="form-control">
		   		                <option value=""> Select State</option>
		   		                <?php 
		   		                	$state_array =array("MICHIGAN","CALIFORNIA","NEW YORK");
		   		                	foreach ($state_array as $state) {
		   		                		$selected = "";
		   		                		if ($details['state'] == $state)
		   		                			$selected = "selected";
		   		                		echo "<option value='".$state."' ".$selected.">".$state."</option>";
		   		                	}
		   		                ?>
		   		            </select>
		   		        </div>
		   		    </div>
		   		    <div class="form-group">
		   		        <label for="inputPassword3" class="col-sm-2 control-label">Zip</label>
		   		        <div class="col-sm-10">
		   		            <input type="text" class="form-control" id="zip" name="zip" value="<?php echo $details['zip']; ?>" placeholder="zip">
		   		        </div>
		   		    </div>
		   		    <h3>Credit Card Details</h3>
		   		    <div class="form-group">
		   		        <label for="inputPassword3" class="col-sm-2 control-label">Credit Card</label>
		   		        <div class="col-sm-10">
		   		            <select id="card_type" name="card_type" class="form-control">
		   		                <option value=""> Select Card Type</option>
		   		                <?php 
		   		                	$card_types =array("VISA","MASTER","DISCOVER");
		   		                	foreach ($card_types as $card_type) {
		   		                		$selected = "";
		   		                		if ($details['cctype'] == $card_type)
		   		                			$selected = "selected";
		   		                		echo "<option value='".$card_type."' ".$selected.">".$card_type."</option>";
		   		                	}
		   		                ?>
		   		            </select>
		   		        </div>
		   		    </div>
		   		    <div class="form-group">
		   		        <label for="inputPassword3" class="col-sm-2 control-label">Credit Card Number</label>
		   		        <div class="col-sm-10">
		   		            <input type="text" class="form-control" id="card_number" name="card_number" value="<?php echo $details['ccno']; ?>" placeholder="Credit Card Number">
		   		        </div>
		   		    </div>
		   		    <div class="form-group">
		   		        <label for="inputPassword3" class="col-sm-2 control-label">Expiration Date</label>
		   		        <div class="col-sm-10">
		   		            <input type="text" class="form-control" id="expiration_date" name="expiration_date" value="<?php echo $details['ccexpdt']; ?>" placeholder="Expiration Date (MM/YY)">
		   		        </div>
		   		    </div>
		   		    <div class="form-group">
		   		        <div class="col-sm-offset-2 col-sm-10">
		   		            <button type="button" class="btn btn-success pull-right">Cancel</button>
		   		            <button type="submit" name="update-details" class="btn btn-danger pull-right" style="margin-right:5px;">Update Details</button>
		   		        </div>
		   		    </div>
		   		</form>
		   </div>
		   <div role="tabpanel" class="tab-pane fade" id="orders">
		   		<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
		   		<?php
   					$sql = "SELECT * FROM custorder WHERE username = '".$_SESSION['customer_username']."' ORDER BY order_id DESC";
					$orders = $db->query($db_connect, $sql);
					$collapse_counter = 1;
					while ($orderDetails = $orders->fetch_assoc()) {
				?>
		   		  	<div class="panel panel-default">
		   		    	<div class="panel-heading" role="tab" id="headingOne">
		   		      	<h4 class="panel-title">
		   		        	<span role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse<?php echo $orderDetails['order_id']; ?>" aria-expanded="true" aria-controls="collapse<?php echo $orderDetails['order_id']; ?>">
		   		          	Order ID : <?php echo $orderDetails['order_id']; ?> &emsp;&emsp;&emsp;&emsp;
		   		          	Amount : <?php echo $orderDetails['amount']; ?> &emsp;&emsp;&emsp;&emsp;
		   		        	</span>
		   		      	</h4>
		   		    	</div>
		   		    	<?php  
		   		    	$collapse = "";
		   		    		if ($collapse_counter == 1)
		   		    		{
		   		    			$collapse_counter++;
		   		    			$collapse = "in";
		   		    		}

		   		    	 ?>
		   		    	<div id="collapse<?php echo $orderDetails['order_id']; ?>" class="panel-collapse collapse <?php echo $collapse; ?>" role="tabpanel" aria-labelledby="headingOne">
			   		      	<div class="panel-body">
			   		      		<div class="table-responsive">
			   		      		  <table class="table table-bordered">
			   		      		   		<thead>
			   		      		   			<tr>
			   		      		   			  <th>S.No</th>
			   		      		   			  <th>Name</th>
			   		      		   			  <th>Category</th>
			   		      		   			  <th>Author</th>
			   		      		   			  <th>Quantity</th>
			   		      		   			  <th>Unit Price</th>
			   		      		   			  <th>Total</th>
			   		      		   			</tr>
			   		      		   		</thead>
			   		      		   		<tbody>
			   		      		   			<?php 
			   		      		   				$counter = 1;
			   		      		   				$sub_total_x = 0;
      		   				   					$sql = "SELECT * FROM order_quantity WHERE order_id = '".$orderDetails['order_id']."'";
      		   									$book = $db->query($db_connect, $sql);
      		   									while ($bookDetails = $book->fetch_assoc()) {
			   		      		   					$sql = "SELECT * FROM book WHERE isbn = '".$bookDetails['isbn']."'";
			   		      							$books = $db->query($db_connect, $sql);
			   		      							$book_details = mysqli_fetch_assoc($books);
			   		      							echo "<tr><td>".$counter."</td>";
			   		      							echo "<td>".$book_details['title']."</td>";
			   		      							echo "<td>".$book_details['category']."</td>";
			   		      							echo "<td>".$book_details['author']."</td>";

			   		      							echo "<td>".$bookDetails['quantity']."";
			   		      							echo "</td>";
			   		      							echo "<td>".$book_details['price']."</td>";
			   		      							$sub_total_x += $bookDetails['quantity']   * $book_details['price'];
			   		      							echo "<td>";
			   		      							echo ($bookDetails['quantity']  * $bookDetails['price']);
			   		      							echo "</td>";
			   		      							echo "</tr>";
			   		      		   					$counter++;
			   		      		   				}
			   		      		   				echo "<tr>";
			   		      		   				echo "<td class='text-right' colspan='6'>Sub - Total</td>";
			   		      		   				echo "<td class='text-left'>".$sub_total_x."</td>";
			   		      		   				echo "</tr>";
			   		      		   			?>
			   		      		   		</tbody>
			   		      		  </table>
			   		      		</div>
			   		      		<button class="btn btn-success pull-right">Print</button>
			   		      	</div>
		   		    	</div>
		   		  	</div>
   		  		<?php
   		  			}
   		     	?>
		   		</div>
		   </div>
		 </div>
	</div>
</div>
<script type="text/javascript">
	function addToCart (isbn) {
		$("#temp").load('../catalog/cart.php?isbn='+isbn+'&addtocart=addtocart',function(){
			$("#cart-count").html(parseInt($("#cart-count").html()) + 1);
			$("#cart-added-conf").modal('show');
		});
	}
</script>
<?php include "../catalog/footer.php"; ?>
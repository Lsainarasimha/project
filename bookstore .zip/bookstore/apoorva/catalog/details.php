<?php include "../catalog/header.php"; 
if(isset($_SESSION['viewed-items']))
{
	if (isset($_SESSION['viewed-items'][''.$_GET['book_id'].'']))
	{
		$_SESSION['viewed-items'][''.$_GET['book_id'].''] = $_SESSION['viewed-items'][$_GET['book_id']] + 1;
	}
	else 
	{
		$_SESSION['viewed-items']["".$_GET['book_id'].""] = 1;
	}
}
else 
	$_SESSION['viewed-items']["".$_GET['book_id'].""] = 1;
?>
<div class="container">
	<h2>All Details</h2>
	<div class="row">
	<?php
		$sql_ext = "";
		if (isset($_GET['book_id']))
			$sql_ext = "WHERE isbn = '".$_GET['book_id']."' AND is_deleted = 0";
		else 
			$sql_ext = "WHERE is_deleted = 0";
		$sql = "SELECT * FROM book ".$sql_ext." ORDER BY title ASC ";
		$books = $db->query($db_connect, $sql);
		while ($row = $books->fetch_assoc()){
	?>
	<div class="container">
			<div class="col-md-4">
			<div class="image_" style="height: 200px;width: 200px;">
			  <?php
					$image_url = "sample.png";
					if ($row['image'] != "")
						$image_url = $row['image'];
				?>
			  	<img style="height: 300px;width: 300px;" src="../assets/images/<?php echo $image_url; ?>">
			  </div>
			</div>
			<div class="col-md-8">

			<ul class="list-group">
			  <li class="list-group-item list-group-item-primary text-center">
			  <div class="title_">
			  	<span class="label label-primary label-custom"><?php echo $row['title']; ?></span>
			  </div>
			  </li>
			  <table class="table table-bordered table-striped"> 
				    		<colgroup> 
				    			<col class="col-xs-1"> 
				    			<col class="col-xs-7"> 
				    		</colgroup> 
							<tbody> 
								<tr> 
									<th scope="row"> <code>Author</code> </th> 
									<td><?php echo $row['author']; ?></td> 
								</tr>
								<tr> 
									<th scope="row"> <code>Description</code> </th> 
									<td> <?php echo $row['description']; ?></td> 
								</tr> 
								<tr> 
									<th scope="row"> <code>Category</code> </th> 
									<td><?php echo $row['category']; ?></td> 
								</tr>
								<tr> 
									<th scope="row"> <code>Publisher</code> </th> 
									<td><?php echo $row['publisher']; ?></td> 
								</tr>
								<tr> 
									<th scope="row"> <code>Price</code> </th> 
									<td><?php echo $row['price']; ?></td> 
								</tr> 
								<tr> 
									<th scope="row"> <code>Stock</code> </th> 
									<td><?php echo $row['quantity']; ?></td> 
								</tr>
							</tbody> 
				    	</table> 
			  <li class="list-group-item list-group-item-primary text-center"><button onclick="addToCart('<?php echo $row['isbn']; ?>');" class="btn btn-success">Buy for <?php echo $row['price']; ?></button></li>
				
			</ul>
				
			</div>
		</div>
		<div class="container">
		<h3>Reviews
		<button type="button" onclick="loadReviewModal();" class="btn btn-sm pull-right">Add Review</button>
		</h3>
			<div class="col-md-12">
				<ul class="list-group">
					<?php
			  	$sql = "SELECT * FROM bookreview WHERE isbn = '".$row['isbn']."'  ORDER BY review ASC";
			  	$reviews = $db->query($db_connect, $sql);
			  	$color_array = array("info", "success", "warning", "danger");
			  	while ($row1 = $reviews->fetch_assoc()){
			  ?>
			  <li class="list-group-item list-group-item-<?php echo $color_array[rand(0, count($color_array))]; ?>"><?php echo $row1['review']; ?></li>
			  <?php } 
			  	if ($reviews->num_rows == 0)
			  		echo "<li class=\"list-group-item list-group-item-primary\">No reviews..</li>"
			  ?>
				</ul>
			</div>
		</div>
	<?php
		}
	?>
	</div>
</div>
<form class="form-horizontal" id="form" method="POST" action="../catalog/cart.php">
<div class="modal fade" id="modal_review" tabindex="-1" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title">Add Your Review</h4>
      </div>
      <div class="modal-body">
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Your Name</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="name" name="name" placeholder="Full Name">
                    <input type="hidden" class="form-control" id="isbn" name="isbn" value="<?php echo $_GET['book_id']; ?>">
                </div>
            </div>
            <div class="form-group">
                <label for="inputPassword3" class="col-sm-2 control-label">Your Review</label>
                <div class="col-sm-10">
                    <textarea class="form-control" id="review" name="review" placeholder="Review"></textarea> 
                </div>
            </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="submit" name="save_review" class="btn btn-primary">Save Review</button>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
</form>
<div id="temp" style="display:none;"></div>
<script type="text/javascript">
	function addToCart (isbn) {
		$("#temp").load('../catalog/cart.php?isbn='+isbn+'&addtocart=addtocart',function(){
			$("#cart-count").html(parseInt($("#cart-count").html()) + 1);
			$("#cart-added-conf").modal('show');
		});
	}
</script>
<script type="text/javascript">
	function loadReviewModal() {
		$("#modal_review").modal('show');
	}
</script>
<?php include "../catalog/footer.php"; ?>
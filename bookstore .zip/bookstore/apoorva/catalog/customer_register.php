<?php include "../catalog/header.php"; 
    if (isset($_POST['register']))
    {
        $firstname       = $_POST['firstname'];
        $lastname        = $_POST['lastname'];
        $username        = $_POST['username'];
        $email_id        = $_POST['email_id'];
        $mobile_number   = $_POST['mobile_number'];
        $password        = $_POST['password'];
        $address         = $_POST['address'];
        $city            = $_POST['city'];
        $state           = $_POST['state'];
        $zip             = $_POST['zip'];
        $card_type       = $_POST['card_type'];
        $card_number     = $_POST['card_number'];
        $expiration_date = $_POST['expiration_date'];
        $sql = "INSERT INTO customer (firstname,lastname,username,pin,street,city,state,zip,cctype,ccno,ccexpdt,email,mobile) VALUES ('".$firstname."','".$lastname."','".$username."','".md5($password)."','".$address."','".$city."','".$state."','".$zip."','".$card_type."','".$card_number."','".$expiration_date."','".$email_id."','".$mobile_number."')";
        $result = $db->query($db_connect, $sql);
        /*Mail*/
        require '../common/class.phpmailer.php';
        require '../common/class.smtp.php';

        $mail = new PHPMailer;

        // $mail->SMTPDebug = 3;                                     // Enable verbose debug output

        $mail->isSMTP();                                            // Set mailer to use SMTP
        $mail->Host = 'smtp.gmail.com';                  // Specify main and backup SMTP servers
        $mail->SMTPAuth = true;                                     // Enable SMTP authentication
        $mail->Username = 'medigle2015@gmail.com';                 // SMTP username
        $mail->Password = '2015medigle2015';                       // SMTP password
        $mail->SMTPSecure = 'tls';                                  // Enable TLS encryption, `ssl` also accepted
        $mail->Port = 587;                                          // TCP port to connect to

        $mail->setFrom('medigle2015@gmail.com', 'BOOKSTORE');
        $mail->addAddress($email_id, 'To');     // Add a recipient
        $mail->addAddress('To');                            // Name is optional

        $mail->isHTML(true);                                        // Set email format to HTML

        $mail->Subject = "Welcome To BOOKSTORE";
        $message = "Hai You have successfully registered with BOOKSTORE<br/><br/>";
        $message .= "Your Details:<br/>";
        $message .= "Name : ".$firstname." ".$lastname ."<br/>";
        // $message .= "Email - Id : ".$_POST['email_id']."<br/>";
        $message .= "Thanks For Choosing Us.<br/>";
        $message .= "ThankYou..<br/>";
        $mail->Body    = $message;
        $mail->AltBody = "This is the body in plain text for non-HTML mail clients";

        if(!$mail->send()) {
            echo "Message could not be sent.";
            // echo "Mailer Error: " . $mail->ErrorInfo;
        } else {
            echo "Message has been sent";
        }
        /*MAil*/
    }

?>
<div class="container">
    <h2>Registration Form</h2>
    <div class="row">
        <form class="form-horizontal" id="form" method="POST" onsubmit="return checkUsername();">
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">First Name</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="firstname" name="firstname" placeholder="First Name">
                <div class="validationerror" id="firstname-error"></div>
                </div>
            </div>
            <div class="form-group">
                <label for="inputPassword3" class="col-sm-2 control-label">Last Name</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="lastname" name="lastname" placeholder="Last Name">
                    <div class="validationerror" id="lastname-error"></div>
                </div>
            </div>
            <div class="form-group">
                <label for="inputPassword3" class="col-sm-2 control-label">Username</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="username" name="username" placeholder="Username">
                <div class="validationerror" id="username-error"></div>
                </div>
            </div>
            <div class="form-group">
                <label for="inputPassword3" class="col-sm-2 control-label">Email - Id</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="email_id" name="email_id" placeholder="Email Id">
                </div>
            </div>
            <div class="form-group">
                <label for="inputPassword3" class="col-sm-2 control-label">Mobile Number</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="mobile_number" name="mobile_number" placeholder="Mobile Number">
                </div>
            </div>
            <div class="form-group">
                <label for="inputPassword3" class="col-sm-2 control-label">Password</label>
                <div class="col-sm-10">
                    <input type="password" class="form-control" id="password" name="password" placeholder="Password">
                </div>
            </div>
            <div class="form-group">
                <label for="inputPassword3" class="col-sm-2 control-label">Repeat Password</label>
                <div class="col-sm-10">
                    <input type="password" class="form-control" id="repeat-password" name="repeat-password" placeholder="Repeat Password">
                </div>
            </div>
            <div class="form-group">
                <label for="inputPassword3" class="col-sm-2 control-label">Address</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="address" name="address" placeholder="Address">
                </div>
            </div>
            <div class="form-group">
                <label for="inputPassword3" class="col-sm-2 control-label">city</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="city" name="city" placeholder="city">
                </div>
            </div>
            <div class="form-group">
                <label for="inputPassword3" class="col-sm-2 control-label">state</label>
                <div class="col-sm-10">
                    <select id="state" name="state" class="form-control">
                        <option value=""> Select State</option>
                        <option value="MICHIGAN">MICHIGAN</option>
                        <option value="CALIFORNIA">CALIFORNIA</option>
                        <option value="NEW YORK">NEW YORK</option>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label for="inputPassword3" class="col-sm-2 control-label">Zip</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="zip" name="zip" placeholder="zip">
                </div>
            </div>
            <h3>Credit Card Details</h3>
            <div class="form-group">
                <label for="inputPassword3" class="col-sm-2 control-label">Credit Card</label>
                <div class="col-sm-10">
                    <select id="card_type" name="card_type" class="form-control">
                        <option value=""> Select Card Type</option>
                        <option value="VISA">VISA</option>
                        <option value="DISCOVER">DISCOVER</option>
                        <option value="MASTER">MASTER</option>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label for="inputPassword3" class="col-sm-2 control-label">Credit Card Number</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="card_number" name="card_number" placeholder="Credit Card Number">
                </div>
            </div>
            <div class="form-group">
                <label for="inputPassword3" class="col-sm-2 control-label">Expiration Date</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="expiration_date" name="expiration_date" placeholder="Expiration Date (MM/YY)">
                </div>
            </div>
            <div class="form-group">
                <div class="col-sm-offset-2 col-sm-10">
                    <button onclick="locaton.href='../catalog/admin_home.php'" type="button" class="btn btn-success pull-right">Cancel</button>
                    <button type="submit" name="register" class="btn btn-danger pull-right" style="margin-right:5px;">Add Me</button>
                </div>
            </div>
        </form>
    </div>
</div>
<script type="text/javascript">
  function addToCart (isbn) {
    $("#temp").load('../catalog/cart.php?isbn='+isbn+'&addtocart=addtocart',function(){
      $("#cart-count").html(parseInt($("#cart-count").html()) + 1);
      $("#cart-added-conf").modal('show');
    });
  }
  function checkUsername(argument) {
         $('.validationerror').css('display','none');
       if($("#firstname").val()=="")
      {
          document.getElementById("firstname-error").innerHTML="PLEASE FILL OUT THIS FIELD WITH ALPHABETS !";    
           $('#firstname-error').css('display','block');
          $("#firstname").focus();
          return divTagDisplayHide(10000);
      }
      else if($("#lastname").val()=="")
      {
          document.getElementById("lastname-error").innerHTML="PLEASE FILL OUT THIS FIELD WITH ALPHABETS !";    
           $('#lastname-error').css('display','block');
          $("#lastname").focus();
          return divTagDisplayHide(10000);
      }
      else if($("#username").val()=="")
      {
          document.getElementById("username-error").innerHTML="PLEASE FILL OUT THIS FIELD WITH ALPHABETS !";    
           $('#username-error').css('display','block');
          $("#username").focus();
          return divTagDisplayHide(10000);
      }
      
      var checkusername = "checkusername";
      var set = false;
        $.ajax({
                   type: "POST",
                   url: "../catalog/cart.php",
                
                   cache: false,
                   async:false,
                   data:{
                        username:$("#username").val(),
                        checkusername:checkusername
                   },
                   success: function(data)
                   {
                       console.log(data);
                       if (data == 1)
                       {
                        set = true;
                        $("#form").attr("action", "../catalog/customer_register.php");
                            return true;
                       }
                        else
                        {
                            alert("Username Already Exists.Sorry....");
                            return false;
                        }
                        
                   },    
                   error: function(jqXHR, textStatus, errorThrown)
                   {
                       alert("error" + jqXHR + textStatus + errorThrown);
                        return false;
                   }

               });
       return set;
  }
   function divTagDisplayHide(time){
            $(".validationerror" ).each(function(){
                    var $this = $(this);
                    setTimeout(function() {            
                        $this.hide();
                    }, time);
                });
            return false;
        }

</script>
<?php include "../catalog/footer.php"; ?>
<?php include "../catalog/header.php"; ?>
<div class="container">
 <!-- Carousel
    ================================================== -->
    <div id="myCarousel" class="carousel slide" data-ride="carousel">
      <!-- Indicators -->
      <ol class="carousel-indicators">
        <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
        <li data-target="#myCarousel" data-slide-to="1"></li>
        <li data-target="#myCarousel" data-slide-to="2"></li>
      </ol>
      <div class="carousel-inner" role="listbox">
        <div class="item active">
          <img class="first-slide" src="../assets/images/16.jpg" alt="First slide">
		  <div class="container">
            <div class="carousel-caption">
              <h1>Here you go</h1>
              <p>There is no friend as loyal as book.</p>
            </div>
          </div>
        </div>
        <div class="item">
          <img class="second-slide" src="../assets/images/17.jpg" alt="Second slide">
          <div class="container">
            <div class="carousel-caption">
              <h1>AThe stunning book.</h1>
              <p>Books are a uniquely portable magic</p>
            </div>
          </div>
        </div>
        <div class="item">
          <img class="third-slide" src="../assets/images/19.jpg" alt="Third slide">
          <div class="container">
            <div class="carousel-caption">
              <h1>One more for good measure.</h1>
              <p>You can't buy happiness but you can buy books.</p>
            </div>
          </div>
        </div>
      </div>
      <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
        <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
      </a>
      <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
        <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
      </a>
    </div><!-- /.carousel -->
	<h2>The books den</h2>
	<div class="row">
	<?php
		$sql = "SELECT * FROM book WHERE is_deleted = 0 ORDER BY title ASC ";
		$books = $db->query($db_connect, $sql);
		while ($row = $books->fetch_assoc()){
	?>
			<div class="col-md-4" onclick="location.href='../catalog/details.php?book_id=<?php echo $row['isbn']; ?>'" style="cursor: pointer;">
				<div class="panel panel-default">
				<?php
					$image_url = "sample.png";
					if ($row['image'] != "")
						$image_url = $row['image'];
				?>
				  	<div class="panel-heading text-center" style="height:200px;background: url('../assets/images/<?php echo $image_url; ?>');">
				  		<span class="label label-primary label-custom"><?php echo $row['title']; ?></span></div>
				  <div class="panel-body">
				    <div class="table-responsive"> 
				    	<table class="table table-bordered table-striped"> 
				    		<colgroup> 
				    			<col class="col-xs-1"> 
				    			<col class="col-xs-7"> 
				    		</colgroup> 
							<tbody> 
								<tr> 
									<th scope="row"> <code>Author</code> </th> 
									<td><?php echo $row['author']; ?></td> 
								</tr>
								<tr> 
									<th scope="row"> <code>Description</code> </th> 
									<td> <div style="width:200px;white-space: nowrap;overflow:hidden;text-overflow: ellipsis;"><?php echo $row['description']; ?></div></td> 
								</tr> 
								<tr> 
									<th scope="row"> <code>Category</code> </th> 
									<td><?php echo $row['category']; ?></td> 
								</tr>
								<tr> 
									<th scope="row"> <code>Publisher</code> </th> 
									<td><?php echo $row['publisher']; ?></td> 
								</tr>
								<tr> 
									<th scope="row"> <code>Price</code> </th> 
									<td><?php echo $row['price']; ?></td> 
								</tr> 
								<tr> 
									<th scope="row"> <code>Stock</code> </th> 
									<td><?php echo $row['quantity']; ?></td> 
								</tr>
							</tbody> 
				    	</table> 
				    </div>
				    <div class="row text-center">
				    	<button class="btn btn-danger" onclick="location.href='../catalog/reviews.php?book_id=<?php echo $row['isbn']; ?>'">Details</button>
				    	<button class="btn btn-success" onclick="addToCart('<?php echo $row['isbn']; ?>');">Buy for <?php echo $row['price']; ?></button>
				    </div>
				  </div>
				</div>
			</div>
	<?php
		}
	?>
	</div>
	<h2>Recently Viewed</h2>
	<div class="row">
	<?php
	if(isset($_SESSION['viewed-items'] )){
		foreach ($_SESSION['viewed-items'] as $key => $value){
		
		$sql = "SELECT * FROM book WHERE isbn = '".$key."' ";
		$book = $db->query($db_connect, $sql);
		$row = $book->fetch_assoc()
	?>
			<div class="col-md-4" onclick="location.href='../catalog/details.php?book_id=<?php echo $row['isbn']; ?>'" style="cursor: pointer;">
				<div class="panel panel-default">
				<?php
					$image_url = "sample.png";
					if ($row['image'] != "")
						$image_url = $row['image'];
				?>
				  	<div class="panel-heading text-center" style="height:200px;background: url('../assets/images/<?php echo $image_url; ?>');">
				  		<span class="label label-primary label-custom"><?php echo $row['title']; ?></span></div>
				  <div class="panel-body">
				    <div class="table-responsive"> 
				    	<table class="table table-bordered table-striped"> 
				    		<colgroup> 
				    			<col class="col-xs-1"> 
				    			<col class="col-xs-7"> 
				    		</colgroup> 
							<tbody> 
								<tr> 
									<th scope="row"> <code>Author</code> </th> 
									<td><?php echo $row['author']; ?></td> 
								</tr>
								<tr> 
									<th scope="row"> <code>Description</code> </th> 
									<td> <div style="width:200px;white-space: nowrap;overflow:hidden;text-overflow: ellipsis;"><?php echo $row['description']; ?></div></td> 
								</tr> 
								<tr> 
									<th scope="row"> <code>Category</code> </th> 
									<td><?php echo $row['category']; ?></td> 
								</tr>
								<tr> 
									<th scope="row"> <code>Publisher</code> </th> 
									<td><?php echo $row['publisher']; ?></td> 
								</tr>
								<tr> 
									<th scope="row"> <code>Price</code> </th> 
									<td><?php echo $row['price']; ?></td> 
								</tr> 
								<tr> 
									<th scope="row"> <code>Stock</code> </th> 
									<td><?php echo $row['quantity']; ?></td> 
								</tr>
							</tbody> 
				    	</table> 
				    </div>
				    <div class="row text-center">
				    	<button class="btn btn-danger" onclick="location.href='../catalog/reviews.php?book_id=<?php echo $row['isbn']; ?>'">Details</button>
				    	<button class="btn btn-success" onclick="addToCart('<?php echo $row['isbn']; ?>');">Buy for <?php echo $row['price']; ?></button>
				    </div>
				  </div>
				</div>
			</div>
	<?php
		}
	}
	else
		echo "<h4 style='margin-left:30px;color:red;'>Sorry, You havent Viewed Any Items Yet.</h4>";
	?>
	</div>
</div>
<div id="temp" style="display:none;"></div>
<script type="text/javascript">
	function addToCart (isbn) {
		var addtocart = "addtocart";
		$.ajax({
		           type: "POST",
		           url: "../catalog/cart.php",
		           data:{
		           		isbn:isbn,
		           		addtocart:addtocart
		           },
		           cache: false,
		           success: function(data)
		           {
		               $("#cart-count").html(parseInt($("#cart-count").html()) + 1);
						$("#cart-added-conf").modal('show');
		                
		           },    
		           error: function(jqXHR, textStatus, errorThrown)
		           {
		               alert("error" + jqXHR + textStatus + errorThrown);
		           }

		       });
	}
</script>
<?php include "../catalog/footer.php"; ?>
<?php include "../catalog/header.php"; ?>
<div class="container">
	<h2>Checkout</h2>
	<div class="row">
	<?php  
		if (isset($_SESSION['customer_username']))
		{
			$sql = "SELECT * FROM customer WHERE username = '".$_SESSION['customer_username']."'";
			$result = $db->query($db_connect, $sql);
			$details = mysqli_fetch_assoc($result);

			$counter = $sub_total = 0;
			if (isset($_SESSION['cart-items'])){
				foreach ($_SESSION['cart-items'] as $key => $value) {
					$counter++;
					$sql = "SELECT * FROM book WHERE isbn = '".$key."'";
					$books = $db->query($db_connect, $sql);
					$row = mysqli_fetch_assoc($books);

					$sub_total += $value * $row['price'];
				}
			}
			if ($counter != 0) {
	?>
		<div class="table-responsive">
		    <div class="table-responsive"> 

		    	<table class="table table-bordered table-striped"> 
		    		<colgroup> 
		    			<col class="col-xs-2"> 
		    			<col class="col-xs-5"> 
		    		</colgroup> 
					<tbody> 
						<tr> 
							<th scope="row"> <code>First Name</code> </th> 
							<td><?php echo $details['firstname']; ?></td> 
						</tr> 
						<tr> 
							<th scope="row"> <code>Last Name</code> </th> 
							<td><?php echo $details['lastname']; ?></td> 
						</tr>
						<tr> 
							<th scope="row"> <code>Username</code> </th> 
							<td><?php echo $details['username']; ?></td> 
						</tr>
						<tr> 
							<th scope="row"> <code>Address</code> </th> 
							<td><?php echo $details['street']; ?></td> 
						</tr> 
						<tr> 
							<th scope="row"> <code>City</code> </th> 
							<td><?php echo $details['city']; ?></td> 
						</tr>
						<tr> 
							<th scope="row"> <code>State</code> </th> 
							<td><?php echo $details['state']; ?></td> 
						</tr>
						<tr> 
							<th scope="row"> <code>Zip</code> </th> 
							<td><?php echo $details['zip']; ?></td> 
						</tr>
						<tr>
							<td class="text-center" colspan="2"><h3>Credit Card Details</h3></td>
						</tr>
						<tr> 
							<th scope="row"> <code>Credit Card</code> </th> 
							<td><?php echo $details['cctype']; ?></td> 
						</tr> 
						<tr> 
							<th scope="row"> <code>Credit Card Number</code> </th> 
							<td><?php echo $details['ccno']; ?></td> 
						</tr>
						<tr> 
							<th scope="row"> <code>Expiry Date</code> </th> 
							<td><?php echo $details['ccexpdt']; ?></td> 
						</tr>
						<tr> 
							<th scope="row"> <code>Total</code> </th> 
							<td><?php echo $sub_total; ?></td> 
						</tr>
					</tbody> 
		    	</table> 
		    </div>
		</div>
		<button class="btn btn-success pull-right" onclick="location.href='../catalog/account.php?checkout=<?php echo md5(uniqid(rand(), true));?>'">Pay Amount</button>
		<div id="temp" style="display:none;"></div>
	<?php
		}
		else 
			echo "<h3><span class=\"glyphicon glyphicon-shopping-cart\" aria-hidden=\"true\"></span> &emsp;Your Cart is EMPTY...</h3>";
	}
	else
		echo "<h3><span class=\"glyphicon glyphicon-shopping-cart\" aria-hidden=\"true\"></span> &emsp;You Must Login to Checkout</h3>";

	?>
	</div>
</div>
<script type="text/javascript">
	function removeFromCart (isbn) {
		$("#temp").load('../catalog/cart.php?isbn='+isbn+'&removefromcart=removefromcart',function(){
			location.reload();
		});
	}
	function reBuild (isbn) {
		var quantity = $("#rebuild_value_"+isbn+"").val();
		$("#temp").load('../catalog/cart.php?isbn='+isbn+'&quantity='+quantity+'&rebuild=rebuild',function(){
			location.reload();
		});
	}

</script>
<?php include "../catalog/footer.php"; ?>
<HTML>

<?php
	if(!isset($_SESSION['username']))
	{	
		session_start();
	}
	$db = mysqli_connect("localhost","root","","readme");
	    if(mysqli_connect_errno())
	{
        print "connect failed:".mysqli_connect_error();
        exit();
    }
	if(isset($_GET['cartisbn']))
			$cartisbn= $_GET['cartisbn'];
		else
			$cartisbn="";
?>
<head>
<title> CUSTOMER REGISTRATION </title>
</head>
<body background="image1.jpg">
	<table align="center" style="border:2px solid blue;">
		<tr>
			<form id="register" action="" method="post">
			<td align="right">
				Username<span style="color:red">*</span>:
			</td>
			<td align="left" colspan="3">
				<input type="text" id="username" name="username" placeholder="Enter your username">
			</td>
		</tr>
		<tr>
			<td align="right">
				PIN<span style="color:red">*</span>:
			</td>
			<td align="left">
				<input type="password" id="pin" name="pin">
			</td>
			<td align="right">
				Re-type PIN<span style="color:red">*</span>:
			</td>
			<td align="left">
				<input type="password" id="retype_pin" name="retype_pin">
			</td>
		</tr>
		<tr>
			<td align="right">
				Firstname<span style="color:red">*</span>:
			</td>
			<td colspan="3" align="left">
				<input type="text" id="firstname" name="firstname" placeholder="Enter your firstname">
			</td>
		</tr>
		<tr>
			<td align="right">
				Lastname<span style="color:red">*</span>:
			</td>
			<td colspan="3" align="left">
				<input type="text" id="lastname" name="lastname" placeholder="Enter your lastname">
			</td>
		</tr>
		<tr>
			<td align="right">
				Address<span style="color:red">*</span>:
			</td>
			<td colspan="3" align="left">
				<input type="text" id="address" name="address">
			</td>
		</tr>
		<tr>
			<td align="right">
				City<span style="color:red">*</span>:
			</td>
			<td colspan="3" align="left">
				<input type="text" id="city" name="city">
			</td>
		</tr>
		<tr>
			<td align="right">
				State<span style="color:red">*</span>:
			</td>
			<td align="left">
				<select id="state" name="state">
				<option selected disabled>select a state</option>
				<option>Michigan</option>
				<option>California</option>
				<option>Tennessee</option>
				</select>
			</td>
			<td align="right">
				Zip<span style="color:red">*</span>:
			</td>
			<td align="left">
				<input type="text" id="zip" name="zip">
			</td>
		</tr>
		<tr>
			<td align="right">
				Credit Card<span style="color:red">*</span>
			</td>
			<td align="left">
				<select id="credit_card" name="credit_card">
				<option selected disabled>select a card type</option>
				<option>VISA</option>
				<option>MASTER</option>
				<option>DISCOVER</option>
				</select>
			</td>
			<td colspan="2" align="left">
				<input type="text" id="card_number" name="card_number" placeholder="Credit card number">
			</td>
		</tr>
		<tr>
			<td colspan="2" align="right">
				Expiration Date<span style="color:red">*</span>:
			</td>
			<td colspan="2" align="left">
				<input type="text" id="creditcardexpirydate" name="creditcardexpirydate" placeholder="MM/YY">
			</td>
		</tr>
		<tr>
			<td colspan="2" align="center"> 
				<input type="submit" id="register_submit" name="register_submit" value="Register">
			</td>
			</form>
			<form id="no_registration" action="" method="post">
			<td colspan="2" align="center">
				<input type="submit" id="donotregister" name="donotregister" value="Don't Register">
			</td>
			</form>
		</tr>
	</table>
</body>
</HTML>
<?php

	if(isset($_POST['register_submit']))
	{
		$username=$_POST['username'];
		$str="insert into customer values('$_POST[username]','$_POST[pin]','$_POST[address]','$_POST[city]','$_POST[state]',$_POST[zip],'$_POST[firstname]','$_POST[lastname]',$_POST[card_number],'$_POST[credit_card]','$_POST[creditcardexpirydate]');";

		$result=  mysqli_query($db, $str);
		if(!$result)
		{
			print "Error- the query could not be executed".mysqli_error($db);
			exit();
		}	
		if(mysqli_affected_rows($db))
		{        
			$message ="Registered successfully!";
			echo "<script type='text/javascript'>alert('$message');</script>";
			$_SESSION['username'] = $username;
			if(isset($_GET['flag']))
				echo "<script>var books='$cartisbn';window.location.href='confirmorder.php?cartisbn='+ books;</script>";
			else
				echo "<script>window.location.href='screen2.php';</script>";
		}
	}
	elseif(isset($_POST['donotregister']))
	{
		if(isset($_GET['flag']))
		{
			$message ="In order to proceed with the payment, you need to register first";
			echo "<script type='text/javascript'>alert('$message');</script>";
			echo "<script>var books='$cartisbn';window.location.href='screen2.php?cartisbn='+ books;</script>";
		}
		else
		{
			echo "<script>var books='$cartisbn';window.location.href='screen1.php';</script>";
		}
	}


?>
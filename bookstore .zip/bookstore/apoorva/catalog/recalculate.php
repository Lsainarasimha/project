<!DOCTYPE HTML>
<html>

<head>
	<title>Shopping Cart1</title>
	<?php
		session_start();
		if(isset($_GET['cartisbn']))
			$cartisbn= $_GET['cartisbn'];
		else
			$cartisbn="";
    ?>
	<script>
		var books='<?= $cartisbn ?>';
		//alert(books);
		window.location.href="manage.php?cartisbn="+ books;
	</script>
</head>
<body></body>
</html>
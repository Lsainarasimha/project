-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 06, 2016 at 03:02 PM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `readme`
--

-- --------------------------------------------------------

--
-- Table structure for table `administrator`
--

CREATE TABLE IF NOT EXISTS `administrator` (
  `username` varchar(50) NOT NULL DEFAULT '',
  `pin` varchar(60) NOT NULL,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `administrator`
--

INSERT INTO `administrator` (`username`, `pin`, `name`) VALUES
('admin', '21232f297a57a5a743894a0e4a801fc3', '');

-- --------------------------------------------------------

--
-- Table structure for table `book`
--

CREATE TABLE IF NOT EXISTS `book` (
  `isbn` decimal(13,0) NOT NULL DEFAULT '0',
  `title` varchar(50) NOT NULL,
  `author` varchar(30) NOT NULL,
  `publisher` varchar(30) NOT NULL,
  `price` decimal(5,2) NOT NULL,
  `category` char(10) NOT NULL,
  `quantity` decimal(3,0) DEFAULT '0',
  `description` text NOT NULL,
  `image` varchar(100) NOT NULL,
  `is_deleted` tinyint(1) NOT NULL,
  PRIMARY KEY (`isbn`),
  KEY `book_category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `book`
--

INSERT INTO `book` (`isbn`, `title`, `author`, `publisher`, `price`, `category`, `quantity`, `description`, `image`, `is_deleted`) VALUES
('454', 'gone with the wind', 'sardar', 'smk', '20.00', 'Romance', '12', 'WIth All pure love', '4.jpg', 0),
('898989988989', 'Philosophy', 'anup', 'starter', '21.00', 'fantasy', '1', 'It can change u r things..', '2.jpg', 0),
('4536277776665', 'Eragon', 'Christopher Paolini', 'Creative Publishers', '30.00', 'Fantasy', '80', 'Fifteenyearold Eragon believes that he is merely a poor farm boy- until his destiny as a Dragon Rider is revealed', '8.jpg', 0),
('5555277776665', 'Dreamcatcher', 'Stephen King', 'White Horses Publishers', '40.00', 'Horror', '90', 'Dream can be catched by using this book', '5.jpg', 0),
('6756977967898', 'Hobbit', 'Harry', '7Hills', '50.00', 'Fantasy', '20', 'Magical world with powers,', '10.jpg', 0),
('9999999999999', 'ecommerse', 'Matthew', 'eastern', '40.00', 'studies', '10', 'All is about studies', '0138018812.jpg', 0);

-- --------------------------------------------------------

--
-- Table structure for table `bookreview`
--

CREATE TABLE IF NOT EXISTS `bookreview` (
  `isbn` decimal(13,0) NOT NULL DEFAULT '0',
  `review` varchar(200) NOT NULL,
  `name` varchar(100) NOT NULL,
  `is_approved` tinyint(1) NOT NULL,
  PRIMARY KEY (`isbn`,`review`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE IF NOT EXISTS `customer` (
  `username` varchar(50) NOT NULL DEFAULT '',
  `pin` varchar(50) NOT NULL,
  `street` varchar(20) NOT NULL,
  `city` varchar(20) NOT NULL,
  `state` char(20) NOT NULL,
  `zip` decimal(5,0) NOT NULL,
  `firstname` varchar(20) NOT NULL,
  `lastname` varchar(20) DEFAULT NULL,
  `ccno` decimal(19,0) NOT NULL,
  `cctype` varchar(20) NOT NULL,
  `ccexpdt` date NOT NULL,
  `email` varchar(100) NOT NULL,
  `country_code` int(11) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`username`, `pin`, `street`, `city`, `state`, `zip`, `firstname`, `lastname`, `ccno`, `cctype`, `ccexpdt`, `email`, `country_code`, `mobile`) VALUES
('', 'd41d8cd98f00b204e9800998ecf8427e', '', '', '', '0', '', '', '0', '', '0000-00-00', '', 0, ''),
('janeaust', 'jane1234', 'Jane street', 'Jane \r\n\r\ncity', 'Wisconsin', '98105', 'Jane', 'Austin', '1234567890', 'visa', '2015-01-01', '', 0, ''),
('robert', 'rob1234', 'Robert street', 'Robert \r\n\r\ncity', 'Michigan', '96605', 'Robert', 'Carpenter', '1000067890', 'mastercard', '2015-01-30', '', 0, ''),
('sivateja', '5f4dcc3b5aa765d61d8327deb882cf99', 'TEja', 'Guntur', 'MICHIGAN', '99999', 'Siva Teja', 'Pesala', '654654', 'DISCOVER', '0000-00-00', '', 0, ''),
('tom', 'tom1234', 'Tom street', 'Tom city', 'Ohio', '11605', 'Tom787', 'pullaka', '7856767890', 'visa', '2015-02-10', '', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `custorder`
--

CREATE TABLE IF NOT EXISTS `custorder` (
  `order_id` int(11) NOT NULL AUTO_INCREMENT,
  `dayofmonth` decimal(2,0) NOT NULL,
  `monthoforder` decimal(2,0) NOT NULL,
  `yearoforder` decimal(4,0) NOT NULL,
  `timeoforder` time NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `username` varchar(50) NOT NULL,
  PRIMARY KEY (`dayofmonth`,`monthoforder`,`yearoforder`,`timeoforder`),
  UNIQUE KEY `order_id` (`order_id`),
  KEY `username` (`username`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=22 ;

--
-- Dumping data for table `custorder`
--

INSERT INTO `custorder` (`order_id`, `dayofmonth`, `monthoforder`, `yearoforder`, `timeoforder`, `amount`, `username`) VALUES
(21, '6', '5', '2016', '14:59:38', '40.00', 'sivateja'),
(16, '12', '12', '2015', '02:43:41', '40.00', 'sivateja'),
(17, '12', '12', '2015', '02:43:45', '0.00', 'sivateja'),
(18, '12', '12', '2015', '02:45:27', '30.00', 'sivateja'),
(19, '12', '12', '2015', '02:46:45', '40.00', 'sivateja'),
(20, '12', '12', '2015', '03:17:07', '30.00', 'sivateja');

-- --------------------------------------------------------

--
-- Table structure for table `order_quantity`
--

CREATE TABLE IF NOT EXISTS `order_quantity` (
  `order_id` int(11) NOT NULL,
  `dayofmonth` decimal(2,0) NOT NULL,
  `monthoforder` decimal(2,0) NOT NULL,
  `yearoforder` decimal(4,0) NOT NULL,
  `timeoforder` time NOT NULL,
  `isbn` decimal(13,0) NOT NULL,
  `quantity` decimal(3,0) NOT NULL,
  `price` float NOT NULL,
  PRIMARY KEY (`dayofmonth`,`monthoforder`,`yearoforder`,`timeoforder`,`isbn`),
  KEY `isbn` (`isbn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `order_quantity`
--

INSERT INTO `order_quantity` (`order_id`, `dayofmonth`, `monthoforder`, `yearoforder`, `timeoforder`, `isbn`, `quantity`, `price`) VALUES
(21, '6', '5', '2016', '14:59:38', '5555277776665', '1', 40),
(16, '12', '12', '2015', '02:43:41', '5555277776665', '1', 40),
(18, '12', '12', '2015', '02:45:27', '4536277776665', '1', 30),
(19, '12', '12', '2015', '02:46:45', '5555277776665', '1', 40),
(20, '12', '12', '2015', '03:17:07', '4536277776665', '1', 30);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bookreview`
--
ALTER TABLE `bookreview`
  ADD CONSTRAINT `bookreview_ibfk_1` FOREIGN KEY (`isbn`) REFERENCES `book` (`isbn`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `custorder`
--
ALTER TABLE `custorder`
  ADD CONSTRAINT `custorder_ibfk_1` FOREIGN KEY (`username`) REFERENCES `customer` (`username`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `order_quantity`
--
ALTER TABLE `order_quantity`
  ADD CONSTRAINT `order_quantity_ibfk_1` FOREIGN KEY (`dayofmonth`, `monthoforder`, `yearoforder`, `timeoforder`) REFERENCES `custorder` (`dayofmonth`, `monthoforder`, `yearoforder`, `timeoforder`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `order_quantity_ibfk_2` FOREIGN KEY (`isbn`) REFERENCES `book` (`isbn`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

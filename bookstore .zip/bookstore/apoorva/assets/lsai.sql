-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 14, 2015 at 06:22 AM
-- Server version: 5.5.40
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `bbb`
--

-- --------------------------------------------------------

--
-- Table structure for table `administrator`
--

CREATE TABLE IF NOT EXISTS `administrator` (
  `username` varchar(50) NOT NULL DEFAULT '',
  `pin` varchar(20) NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `administrator`
--

INSERT INTO `administrator` (`username`, `pin`) VALUES
('admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `book`
--

CREATE TABLE IF NOT EXISTS `book` (
  `isbn` decimal(13,0) NOT NULL DEFAULT '0',
  `title` varchar(50) NOT NULL,
  `author` varchar(30) NOT NULL,
  `publisher` varchar(30) NOT NULL,
  `price` decimal(5,2) NOT NULL,
  `category` char(10) NOT NULL,
  `quantity` decimal(3,0) DEFAULT '0',
  PRIMARY KEY (`isbn`),
  KEY `book_category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `book`
--

INSERT INTO `book` (`isbn`, `title`, `author`, `publisher`, `price`, `category`, `quantity`) VALUES
('1248887776665', 'The Return of the King', 'J.R.R. Tolkien', 'Dream-\r\n\r\nWorks', '50.00', 'Fantasy', '60'),
('4448887776665', 'The Hobbit', 'J.R.R. Tolkien', 'Dream-Works', '70.00', 'Fantasy', '50'),
('4536277776665', 'Eragon', 'Christopher Paolini', 'Creative \r\n\r\nPublishers', '30.00', 'Fantasy', '80'),
('5555277776665', 'Dreamcatcher', 'Stephen King', 'White Horses \r\n\r\nPublishers', '40.00', 'Horror', '90'),
('9998887776665', 'SQL Server 2000 for Experienced DBAs', 'Brian \r\n\r\nKnight', 'McGraw-Hill Osborne Media 2003', '100.00', 'Science', '50');

-- --------------------------------------------------------

--
-- Table structure for table `bookreview`
--

CREATE TABLE IF NOT EXISTS `bookreview` (
  `isbn` decimal(13,0) NOT NULL DEFAULT '0',
  `review` varchar(200) NOT NULL,
  PRIMARY KEY (`isbn`,`review`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `bookreview`
--

INSERT INTO `bookreview` (`isbn`, `review`) VALUES
('1248887776665', 'Interesting book'),
('9998887776665', 'Good reference'),
('9998887776665', 'Very intuitive');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE IF NOT EXISTS `customer` (
  `username` varchar(50) NOT NULL DEFAULT '',
  `pin` varchar(20) NOT NULL,
  `street` varchar(20) NOT NULL,
  `city` varchar(20) NOT NULL,
  `state` char(20) NOT NULL,
  `zip` decimal(5,0) NOT NULL,
  `firstname` varchar(20) NOT NULL,
  `lastname` varchar(20) DEFAULT NULL,
  `ccno` decimal(19,0) NOT NULL,
  `cctype` varchar(20) NOT NULL,
  `ccexpdt` date NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`username`, `pin`, `street`, `city`, `state`, `zip`, `firstname`, `lastname`, `ccno`, `cctype`, `ccexpdt`) VALUES
('janeaust', 'jane1234', 'Jane street', 'Jane \r\n\r\ncity', 'Wisconsin', '98105', 'Jane', 'Austin', '1234567890', 'visa', '2015-01-01'),
('robert', 'rob1234', 'Robert street', 'Robert \r\n\r\ncity', 'Michigan', '96605', 'Robert', 'Carpenter', '1000067890', 'mastercard', '2015-01-30'),
('tom', 'tom1234', 'Tom street', 'Tom city', 'Ohio', '11605', 'Tom787', 'pullaka', '7856767890', 'visa', '2015-02-10');

-- --------------------------------------------------------

--
-- Table structure for table `custorder`
--

CREATE TABLE IF NOT EXISTS `custorder` (
  `dayofmonth` decimal(2,0) NOT NULL,
  `monthoforder` decimal(2,0) NOT NULL,
  `yearoforder` decimal(4,0) NOT NULL,
  `timeoforder` time NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `username` varchar(50) NOT NULL,
  PRIMARY KEY (`dayofmonth`,`monthoforder`,`yearoforder`,`timeoforder`),
  KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `custorder`
--

INSERT INTO `custorder` (`dayofmonth`, `monthoforder`, `yearoforder`, `timeoforder`, `amount`, `username`) VALUES
('1', '6', '2013', '11:17:10', '150.00', 'tom'),
('11', '3', '2014', '02:19:19', '70.00', 'janeaust'),
('20', '2', '2014', '23:59:59', '100.00', 'robert');

-- --------------------------------------------------------

--
-- Table structure for table `order_quantity`
--

CREATE TABLE IF NOT EXISTS `order_quantity` (
  `dayofmonth` decimal(2,0) NOT NULL,
  `monthoforder` decimal(2,0) NOT NULL,
  `yearoforder` decimal(4,0) NOT NULL,
  `timeoforder` time NOT NULL,
  `isbn` decimal(13,0) NOT NULL,
  `quantity` decimal(3,0) NOT NULL,
  PRIMARY KEY (`dayofmonth`,`monthoforder`,`yearoforder`,`timeoforder`,`isbn`),
  KEY `isbn` (`isbn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `order_quantity`
--

INSERT INTO `order_quantity` (`dayofmonth`, `monthoforder`, `yearoforder`, `timeoforder`, `isbn`, `quantity`) VALUES
('1', '6', '2013', '11:17:10', '1248887776665', '1'),
('1', '6', '2013', '11:17:10', '9998887776665', '1'),
('11', '3', '2014', '02:19:19', '4448887776665', '1'),
('20', '2', '2014', '23:59:59', '9998887776665', '1');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bookreview`
--
ALTER TABLE `bookreview`
  ADD CONSTRAINT `bookreview_ibfk_1` FOREIGN KEY (`isbn`) REFERENCES `book` (`isbn`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `custorder`
--
ALTER TABLE `custorder`
  ADD CONSTRAINT `custorder_ibfk_1` FOREIGN KEY (`username`) REFERENCES `customer` (`username`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `order_quantity`
--
ALTER TABLE `order_quantity`
  ADD CONSTRAINT `order_quantity_ibfk_1` FOREIGN KEY (`dayofmonth`, `monthoforder`, `yearoforder`, `timeoforder`) REFERENCES `custorder` (`dayofmonth`, `monthoforder`, `yearoforder`, `timeoforder`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `order_quantity_ibfk_2` FOREIGN KEY (`isbn`) REFERENCES `book` (`isbn`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

<?php
  header("Expires: Thu, 19 Nov 1981 08:52:00 GMT"); //Date in the past
  header("Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0"); //HTTP/1.1
  header("Pragma: no-cache");
						// Redirects to login page if there is no session available
	require_once("../common/Database.php");
	$db = new Database;
	$db_connect = $db->connect();
	if (!isset($_SESSION['admin_username']))
        header("Location: ../common/login.php");

    if (isset($_POST['add']))
    {
        $sql = "INSERT INTO administrator (name,username,pin) VALUES ('".$_POST['name']."','".$_POST['username_s']."','".md5($_POST['password'])."')";
        $result=  $db->query($db_connect, $sql);
        header("Location: ../admin/admins.php");
    }
    if (isset($_POST['edit'])){
        $sql = "UPDATE administrator SET name = '".$_POST['name']."', username = '".$_POST['username_s']."' WHERE username = '".$_POST['username']."'";
        $result=  $db->query($db_connect, $sql);
    header("Location: ../admin/admins.php");
    }
    if (isset($_POST['update_password'])){
        $sql = "UPDATE administrator SET pin = '".md5($_POST['password'])."' WHERE username = '".$_POST['username']."'";
        $result=  $db->query($db_connect, $sql);
		header("Location: ../admin/admins.php");
    }
    if (isset($_GET['delete'])){
        $sql = "DELETE from administrator  WHERE username = '".$_GET['username']."'";
        $result=  $db->query($db_connect, $sql);
        header("Location: ../admin/admins.php");
    }
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../favicon.ico">

    <title>Books</title>

    <!-- Bootstrap core CSS -->

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->

    <!-- Custom styles for this template -->
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/custom.css">
    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    <style type="text/css">
    	/*
    	 * Base structure
    	 */

    	/* Move down content because we have a fixed navbar that is 50px tall */
    	body {
    	  padding-top: 50px;
    	}


    	/*
    	 * Global add-ons
    	 */

    	.sub-header {
    	  padding-bottom: 10px;
    	  border-bottom: 1px solid #eee;
    	}

    	/*
    	 * Top navigation
    	 * Hide default border to remove 1px line.
    	 */
    	.navbar-fixed-top {
    	  border: 0;
    	}

    	/*
    	 * Sidebar
    	 */

    	/* Hide for mobile, show later */
    	.sidebar {
    	  display: none;
    	}
    	@media (min-width: 768px) {
    	  .sidebar {
    	    position: fixed;
    	    top: 78px;
    	    bottom: 0;
    	    left: 0;
    	    z-index: 1000;
    	    display: block;
    	    padding: 20px;
    	    overflow-x: hidden;
    	    overflow-y: auto; /* Scrollable contents if viewport is shorter than content. */
    	    background-color: #f5f5f5;
    	    border-right: 1px solid #eee;
    	  }
    	}

    	/* Sidebar navigation */
    	.nav-sidebar {
    	  margin-right: -21px; /* 20px padding + 1px border */
    	  margin-bottom: 20px;
    	  margin-left: -20px;
    	}
    	.nav-sidebar > li > a {
    	  padding-right: 20px;
    	  padding-left: 20px;
    	}
    	.nav-sidebar > .active > a,
    	.nav-sidebar > .active > a:hover,
    	.nav-sidebar > .active > a:focus {
    	  color: #fff;
    	  background-color: #428bca;
    	}


    	/*
    	 * Main content
    	 */

    	.main {
    	  padding: 20px;
    	}
    	@media (min-width: 768px) {
    	  .main {
    	    padding-right: 40px;
    	    padding-left: 40px;
    	  }
    	}
    	.main .page-header {
    	  margin-top: 0;
    	}


    	/*
    	 * Placeholder dashboard ideas
    	 */

    	.placeholders {
    	  margin-bottom: 30px;
    	  text-align: center;
    	}
    	.placeholders h4 {
    	  margin-bottom: 0;
    	}
    	.placeholder {
    	  margin-bottom: 20px;
    	}
    	.placeholder img {
    	  display: inline-block;
    	  border-radius: 50%;
    	}
    	.img-text{
    		position: absolute;
    		margin-left: 36%;
    		top: 13%;
    		font-size: 108px;
    		color: rgb(56, 26, 66);
    	}
    </style>
  </head>

  <body>

    <nav class="navbar navbar-inverse navbar-fixed-top">
      <div class="container-fluid">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#">HELLO ADMIN</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav navbar-right">
            <li><a href="../admin/admin_home.php">Home</a></li>
            <li><a href="../admin/books.php">Books</a></li>
            <li><a href="../common/login.php?admin_action=logout">Logout</a></li>
          </ul>
        </div>
      </div>
    </nav>

    <div class="container-fluid" style="margin-top:30px;">
      <div class="row">
        <div class="col-sm-3 col-md-2 sidebar">
          <ul class="nav nav-sidebar">
            <li><a href="../admin/admin_home.php">Home</a></li>
            <li><a href="../admin/books.php">Books</a></li>
          </ul>
        </div>
        <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
            <?php if ($_GET['type'] == "add") { ?>
                <h1 class="page-header">Add New Admin </h1>
            <?php } else if ($_GET['type'] == "edit" || $_GET['type'] == "change_password") { 
                    $query="SELECT * FROM administrator where username = '".$_GET['username']."'";
                    $result=  $db->query($db_connect, $query);
                    $row = mysqli_fetch_assoc($result);
                ?>
                <h1 class="page-header">Update Admin</h1>
            <?php } ?>
          <form class="form-horizontal" method="POST">
          <?php 
                if ($_GET['type'] != "change_password") {
              ?>   
              <div class="form-group">
                  <label for="inputEmail3" class="col-sm-2 control-label">Name</label>
                  <div class="col-sm-10">
                      <input type="text" class="form-control" id="name" name="name" value="<?php if (isset($row['name']))echo $row['name']; ?>" placeholder="Admin Name">
                  </div>
              </div>
              <?php  } ?>
              <?php if (isset($row['username'])) { ?>
              <input type="hidden" class="form-control" id="username" name="username" value="<?php echo $row['username']; ?>">
              <?php } ?>
              <?php 
                if ($_GET['type'] != "change_password") {
              ?>  
              <div class="form-group">
                  <label for="inputPassword3" class="col-sm-2 control-label">username</label>
                  <div class="col-sm-10">
                      <input type="text" class="form-control" id="username_s" name="username_s" placeholder="Username" value="<?php if (isset($row['username']))echo $row['username']; ?>">
                  </div>
              </div>  
              <?php } ?>
              <?php 
                if ($_GET['type'] == "add" || $_GET['type'] == "change_password") {
              ?>   
              <div class="form-group">
                  <label for="inputPassword3" class="col-sm-2 control-label">Password</label>
                  <div class="col-sm-10">
                      <input type="text" class="form-control" id="password" name="password" placeholder="Password" >
                  </div>
              </div>    
              <?php } ?>   
              <?php 
                if ($_GET['type'] == "change_password") {
              ?>   
              <div class="form-group">
                  <label for="inputPassword3" class="col-sm-2 control-label">Repeat Password</label>
                  <div class="col-sm-10">
                      <input type="text" class="form-control" id="password_r" name="password_r" placeholder="Password" >
                  </div>
              </div>    
              <?php } ?>    
              <div class="form-group">
                  <div class="col-sm-offset-2 col-sm-10">
                      <button type="button" class="btn btn-success pull-right" onclick="location.href='<?php echo "../admin/admins.php"; ?>'">Cancel</button>
                      <?php if ($_GET['type'] == "add") { ?>
                      <button type="submit" name="add" class="btn btn-danger pull-right" style="margin-right:5px;">Add</button>
                      <?php } else if ($_GET['type'] == "edit") { ?>
                      <button type="submit" name="edit" class="btn btn-danger pull-right" style="margin-right:5px;">Update</button>
                      <?php }  else if ($_GET['type'] == "change_password") { ?>
                      <button type="submit" name="update_password" class="btn btn-danger pull-right" style="margin-right:5px;">Update Password</button>
                      <?php } ?>
                  </div>
              </div>
          </form>
        </div>
      </div>
    </div>

    <script type="text/javascript" src="../assets/jquery_latest.js"></script>
	<script type="text/javascript" src="../assets/js/bootstrap.min.js"></script>
  </body>
</html>

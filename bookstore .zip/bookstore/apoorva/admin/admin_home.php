<?php
  header("Expires: Thu, 19 Nov 1981 08:52:00 GMT"); //Date in the past
  header("Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0"); //HTTP/1.1
  header("Pragma: no-cache");
						// Redirects to login page if there is no session available
	require_once("../common/Database.php");
	$db = new Database;
	$db_connect = $db->connect();
	if (!isset($_SESSION['admin_username']))
		header("Location: ../common/login.php");
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../favicon.ico">

    <title>Dashboard</title>

    <!-- Bootstrap core CSS -->

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->

    <!-- Custom styles for this template -->
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/custom.css">
    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    <style type="text/css">
    	/*
    	 * Base structure
    	 */

    	/* Move down content because we have a fixed navbar that is 50px tall */
    	body {
    	  padding-top: 50px;
    	}


    	/*
    	 * Global add-ons
    	 */

    	.sub-header {
    	  padding-bottom: 10px;
    	  border-bottom: 1px solid #eee;
    	}

    	/*
    	 * Top navigation
    	 * Hide default border to remove 1px line.
    	 */
    	.navbar-fixed-top {
    	  border: 0;
    	}

    	/*
    	 * Sidebar
    	 */

    	/* Hide for mobile, show later */
    	.sidebar {
    	  display: none;
    	}
    	@media (min-width: 768px) {
    	  .sidebar {
    	    position: fixed;
    	    top: 78px;
    	    bottom: 0;
    	    left: 0;
    	    z-index: 1000;
    	    display: block;
    	    padding: 20px;
    	    overflow-x: hidden;
    	    overflow-y: auto; /* Scrollable contents if viewport is shorter than content. */
    	    background-color: #f5f5f5;
    	    border-right: 1px solid #eee;
    	  }
    	}

    	/* Sidebar navigation */
    	.nav-sidebar {
    	  margin-right: -21px; /* 20px padding + 1px border */
    	  margin-bottom: 20px;
    	  margin-left: -20px;
    	}
    	.nav-sidebar > li > a {
    	  padding-right: 20px;
    	  padding-left: 20px;
    	}
    	.nav-sidebar > .active > a,
    	.nav-sidebar > .active > a:hover,
    	.nav-sidebar > .active > a:focus {
    	  color: #fff;
    	  background-color: #428bca;
    	}


    	/*
    	 * Main content
    	 */

    	.main {
    	  padding: 20px;
    	}
    	@media (min-width: 768px) {
    	  .main {
    	    padding-right: 40px;
    	    padding-left: 40px;
    	  }
    	}
    	.main .page-header {
    	  margin-top: 0;
    	}


    	/*
    	 * Placeholder dashboard ideas
    	 */

    	.placeholders {
    	  margin-bottom: 30px;
    	  text-align: center;
    	}
    	.placeholders h4 {
    	  margin-bottom: 0;
    	}
    	.placeholder {
    	  margin-bottom: 20px;
    	}
    	.placeholder img {
    	  display: inline-block;
    	  border-radius: 50%;
    	}
    	.img-text{
    		    position: relative;
        /* margin-left: 33%; */
        text-align: center;
        vertical-align: middle;
        /* top: 13%; */
        color: rgb(56, 26, 66);
        font-size: 6.9vw;
        background-color: #777777;
        border-radius: 5%;
        overflow: hidden;
        /* min-width: 160px; */
    	}
    </style>
  </head>

  <body>

    <nav class="navbar navbar-inverse navbar-fixed-top">
      <div class="container-fluid">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#">HELLO ADMIN</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav navbar-right">
            <li><a href="../admin/admin_home.php">Home</a></li>
            <li><a href="../admin/books.php">Books</a></li>
			<li><a href="../admin/admins.php">Admins</a></li>
            <li><a href="../common/login.php?admin_action=logout">Logout</a></li>
          </ul>
        </div>
      </div>
    </nav>

    <div class="container-fluid" style="margin-top:30px;">
      <div class="row">
        <div class="col-sm-3 col-md-2 sidebar">
          <ul class="nav nav-sidebar">
            <li><a href="../admin/admin_home.php">Home</a></li>
            <li><a href="../admin/books.php">Books</a></li>
          </ul>
        </div>
        <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
          <h1 class="page-header">Dashboard</h1>
          <!-- <h3 style="text-align:center;"> Total number of registered customers in the system</h3> -->
          <?php

          	$query="SELECT count(*) FROM customer;";
          	//echo $query;
          	$result=  $db->query($db_connect, $query);
          	$num_rows = mysqli_num_rows($result);
          	if ($num_rows>0)
          	{
          		$row= mysqli_fetch_assoc($result);
          		$values = array_values($row);
          		// print"<table align='center'>";
          		// print"<th>Total number of registered customers</th>";
          		// print"<tr><td></td></tr>";
          		// print"</table>";
          	}
          ?>
          <div class="row placeholders">
            <div class="col-xs-6 col-sm-3 placeholder">
              <!-- <img src="data:image/gif;base64,R0lGODlhAQABAIAAAHd3dwAAACH5BAAAAAAALAAAAAABAAEAAAICRAEAOw==" width="200" height="200" class="img-responsive" alt="Generic placeholder thumbnail"> -->
              <div class="img-text"><?php echo $values[0]; ?></div>
              <h4>Customers</h4>
              <span class="text-muted">Total Customers Registered</span>
            </div>
            <div class="col-xs-6 col-sm-3 placeholder">
              <!-- <img src="data:image/gif;base64,R0lGODlhAQABAIAAAHd3dwAAACH5BAAAAAAALAAAAAABAAEAAAICRAEAOw==" width="200" height="200" class="img-responsive" alt="Generic placeholder thumbnail"> -->
              <div class="img-text"><?php 
              	$query="SELECT * FROM book;";
              	//echo $query;
              	$result=  $db->query($db_connect, $query);
              	$num_rows = mysqli_num_rows($result);
              		echo $num_rows; 
              ?></div>
              <h4>Books</h4>
              <span class="text-muted">Total Number Of Books</span>
            </div>
            <div class="col-xs-6 col-sm-3 placeholder">
              <!-- <img src="data:image/gif;base64,R0lGODlhAQABAIAAAHd3dwAAACH5BAAAAAAALAAAAAABAAEAAAICRAEAOw==" width="200" height="200" class="img-responsive" alt="Generic placeholder thumbnail"> -->
              <div class="img-text"><?php 
              	$query="SELECT * FROM custorder;";
              	//echo $query;
              	$result=  $db->query($db_connect, $query);
              	$num_rows = mysqli_num_rows($result);
              		echo $num_rows;
              ?></div>
              <h4>Orders</h4>
              <span class="text-muted">Total Orders</span>
            </div>
            <div class="col-xs-6 col-sm-3 placeholder">
              <!-- <img src="data:image/gif;base64,R0lGODlhAQABAIAAAHd3dwAAACH5BAAAAAAALAAAAAABAAEAAAICRAEAOw==" width="200" height="200" class="img-responsive" alt="Generic placeholder thumbnail"> -->
              <div class="img-text"><?php 
              $query="SELECT SUM(amount) FROM custorder";
              	//echo $query;
              	$result=  $db->query($db_connect, $query);
              	$num_rows = mysqli_num_rows($result);
              		$row= mysqli_fetch_assoc($result);
          		$values = array_values($row);
          		echo (int)$values[0];
              ?></div>
              <h4>Revenue</h4>
              <span class="text-muted">Total Revenue</span>
            </div>
          </div>

        </div>
      </div>
    </div>

    <script type="text/javascript" src="../assets/jquery_latest.js"></script>
	<script type="text/javascript" src="../assets/js/bootstrap.min.js"></script>
  </body>
</html>

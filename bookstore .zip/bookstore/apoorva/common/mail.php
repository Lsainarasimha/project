<?php

if(isset($_POST['name']) && isset($_POST['mobile_number']) && isset($_POST['product_type'])){

	require ''.dirname(__FILE__).DIRECTORY_SEPARATOR.'/class.phpmailer.php';
	require ''.dirname(__FILE__).DIRECTORY_SEPARATOR.'/class.smtp.php';

	$mail = new PHPMailer;

	//$mail->SMTPDebug = 3;                               		// Enable verbose debug output

	$mail->isSMTP();                                      		// Set mailer to use SMTP
	$mail->Host = 'ssl://smtp.googlemail.com';  				// Specify main and backup SMTP servers
	$mail->SMTPAuth = true;                               		// Enable SMTP authentication
	$mail->Username = 'mittapalligroup1@gmail.com';                 // SMTP username
	$mail->Password = 'mittapalli2015';                       // SMTP password
	$mail->SMTPSecure = 'ssl';                            		// Enable TLS encryption, `ssl` also accepted
	$mail->Port = 465;                                    		// TCP port to connect to

	$mail->setFrom('mittapalligroup1@gmail.com', 'From');
	$mail->addAddress('matobaccos@gmail.com', 'To');     // Add a recipient
	$mail->addAddress('To');               				// Name is optional

	$mail->isHTML(true);                                  		// Set email format to HTML

	$mail->Subject = "".$_POST['subject']." - ".$_POST['product_type']."";
	$message = "Hai You have an Enquiry From themitaapalli.com <br/><br/>";
	$message .= "Form Details:<br/>";
	$message .= "Name : ".$_POST['name']."<br/>";
	$message .= "Email - Id : ".$_POST['email_id']."<br/>";
	$message .= "Mobile Number : ".$_POST['mobile_number']."<br/>";
	$message .= "Subject : ".$_POST['subject']."<br/>";
	$message .= "Product Type : ".$_POST['product_type']."<br/>";
	$message .= "Message : ".$_POST['message']."<br/>";
	$message .= "ThankYou..<br/>";
	$mail->Body    = $message;
	$mail->AltBody = "This is the body in plain text for non-HTML mail clients";

	if(!$mail->send()) {
	    echo "Message could not be sent.";
	    echo "Mailer Error: " . $mail->ErrorInfo;
	} else {
	    echo "Message has been sent";
	}
}

?>
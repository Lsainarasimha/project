<?php
	require_once("Database.php");
	$db = new Database;
	$db_connect = $db->connect();
						// Redirects to home page if there is any session available
	/*if (isset($_SESSION['session']))
	{
		if (isset($_SESSION['admin_username']))
			header("Location: ../admin/admin_home.php");
		else
			header("Location: ../catalog/customer_home.php");
	}*/
				// Checks for login form submission
	if(isset($_POST['forgot_password']))
	{
	  	$email_id 	= $_POST['email_id'];

	  	$query = "SELECT * FROM customer WHERE email = '".$email_id."' ";
	  	$customers = $db->query($db_connect, $query);
	  	if (mysqli_num_rows($customers) > 0)
	  	{
	  		/*$query = "SELECT * FROM administrator WHERE username ='".$username."' AND pin ='".md5($pin)."'";
	  		$admins = $db->query($db_connect, $query);  
	  		if (mysqli_num_rows($admins) <= 0)
	  		{
	  			$message = "Incorrect Username or Password";
	  		}
	  		else
	  		{
	  			$_SESSION['admin_username'] = $username;
	  										// redirects to respective homes
	  			header("Location: ../admin/admin_home.php");
	  		}*/
	  		$randnum = mt_rand();
	  		$query = "update customer set pin= '".md5($randnum)."' WHERE email = '".$email_id."' ";
	  		$result = $db->query($db_connect, $query);
	  		$row = $customers->fetch_assoc();
	  		/*Mail*/
        require '../common/class.phpmailer.php';
        require '../common/class.smtp.php';

        $mail = new PHPMailer;

        // $mail->SMTPDebug = 3;                                     // Enable verbose debug output

        $mail->isSMTP();                                            // Set mailer to use SMTP
        $mail->Host = 'smtp.gmail.com';                  // Specify main and backup SMTP servers
        $mail->SMTPAuth = true;                                     // Enable SMTP authentication
        $mail->Username = 'medigle2015@gmail.com';                 // SMTP username
        $mail->Password = '2015medigle2015';                       // SMTP password
        $mail->SMTPSecure = 'tls';                                  // Enable TLS encryption, `ssl` also accepted
        $mail->Port = 587;                                          // TCP port to connect to

        $mail->setFrom('medigle2015@gmail.com', 'From');
        $mail->addAddress('teja22031993@gmail.com', 'To');     // Add a recipient
        $mail->addAddress('To');                            // Name is optional

        $mail->isHTML(true);                                        // Set email format to HTML

        $mail->Subject = "Password Reset Details";
        $message = "Hai We have reset your password.<br/><br/>";
        $message .= "Your New Password is: ".$randnum."<br/>";
        // $message .= "Email - Id : ".$_POST['email_id']."<br/>";
        $message .= "ThankYou..<br/>";
        $mail->Body    = $message;
        $mail->AltBody = "This is the body in plain text for non-HTML mail clients";

        if(!$mail->send()) {
            // echo "Message could not be sent.";
            // echo "Mailer Error: " . $mail->ErrorInfo;
        } else {
            // echo "Message has been sent";
        }
        /*MAil*/
        $message = "Message has been sent to ".$email_id."";
	  	}
	}
	else if (isset($_GET['action']))
	{
		unset($_SESSION['customer_username']);
		// header("Location: ../common/login.php");
	}

?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>:: Secure Login ::</title>
		<link rel="stylesheet" href="../assets/css/bootstrap.min.css">
		<link rel="stylesheet" href="../assets/css/custom.css">
	</head>
<body background="../assets/image3.jpg">
	<div class="container" style="width:500px;">

	      <form class="form-signin" action="forgot_password.php" method="post" id="login_form">
	        <h2 class="form-signin-heading">Please Enter Your Email</h2>
	        <label for="inputEmail" class="sr-only">Email - Id</label>
	        <input type="text" id="email_id" name="email_id" class="form-control" placeholder="Email - Id" required autofocus>
	        <br/>
	        <!-- <div class="checkbox">
	          <label>
	            <input type="checkbox" value="remember-me"> Remember me
	          </label>
	        </div> -->
	        <br/>
	        <button class="btn btn-lg btn-primary btn-block" type="submit" name="forgot_password">Send Me Instructions</button>
	        <br/>
	        <br/><a href="../common/login.php" class="pull-right"> << Back to Login</a>
	      </form>

	    </div> <!-- /container -->
</body>
<script type="text/javascript" src="../assets/jquery_latest.js"></script>
<script type="text/javascript" src="../assets/js/bootstrap.min.js"></script>
</html>
<?php
	if (isset($message))
		echo "<script type='text/javascript'>alert('$message');</script>";
?>

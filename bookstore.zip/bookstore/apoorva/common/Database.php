<?php
	ob_start();
	session_start();
	define('DB_HOST', 'localhost');
	define('DB_USER', 'root');
	define('DB_PWORD', '');
	define('DB_NAME', 'readme');
	class Database
	{

		public function connect()
		{
			$dbq = mysqli_connect(DB_HOST, DB_USER, DB_PWORD, DB_NAME);
			if(mysqli_connect_errno())
			{
				print "connect failed:".mysqli_connect_error();
				exit();
			}
			else
			 	return $dbq;
		}
		public function query($db, $query)
		{
			$result=  mysqli_query($db, $query);
			if(!$result)
			{
				print "Error- the query could not be executed ".mysqli_error($db);
				exit();
			}
			else
			{
				return $result;
			}
		}
		public function getInsertId($db)
		{
			return mysqli_insert_id($db);
		}		
	}
?>
<?php 
	include "../catalog/header.php"; 
	$search_word = $_GET['search-word'];
?>
<div class="container">
	<div class="row">
		<h6>Refine Search : </h6>
		<form class="form-inline col-md-offset-5" method="GET" action="../catalog/search.php">
		  <div class="form-group">
		    <label class="sr-only" for="exampleInputAmount">Categories</label>
		    <div class="input-group">
		      <div class="input-group-addon">Search By Category</div>
		      <select id="category" name="category" class="form-control">
		      <?php
		      	$sql = "SELECT * FROM book GROUP BY category  ORDER BY category ASC";
		      	$books = $db->query($db_connect, $sql);
		      	while ($row = $books->fetch_assoc()){
		      	echo "<option value='".$row['category']."'>".ucwords($row['category'])."</option>";
		      	}
		      	echo "<option value='all'>All</option>";
		      ?>
		      </select>
		      <input type="hidden" id="search-word" name="search-word" value="<?php echo $_GET['search-word']; ?>">
		    </div>
		  </div>
		  <button type="submit" class="btn btn-primary">Search</button>
		</form> 
	</div>
	<?php
		$sql_ext = "";
		if (isset($_GET['category'])) 
		{
			if ($_GET['category'] != "all")
				$sql_ext = "AND category = '".$_GET['category']."'";
		}
		$sql = "SELECT * FROM book WHERE (title LIKE '%".$search_word."%' OR publisher LIKE '%".$search_word."%' OR author LIKE '%".$search_word."%') ".$sql_ext." ORDER BY title ASC";
		$books = $db->query($db_connect, $sql);
		echo "<h2>Search Results (".$books->num_rows.")</h2>";
		echo "<div class=\"row\">";
		while ($row = $books->fetch_assoc()){
	?>
		<div class="col-md-4">
			<div class="panel panel-default">
			  	<div class="panel-heading text-center"><span class="label label-primary label-custom"><?php echo $row['title']; ?></span></div>
			  <div class="panel-body">
			    <div class="table-responsive"> 
			    	<table class="table table-bordered table-striped"> 
			    		<colgroup> 
			    			<col class="col-xs-1"> 
			    			<col class="col-xs-7"> 
			    		</colgroup> 
						<tbody> 
							<tr> 
								<th scope="row"> <code>Author</code> </th> 
								<td><?php echo $row['author']; ?></td> 
							</tr> 
							<tr> 
								<th scope="row"> <code>Category</code> </th> 
								<td><?php echo $row['category']; ?></td> 
							</tr>
							<tr> 
								<th scope="row"> <code>Publisher</code> </th> 
								<td><?php echo $row['publisher']; ?></td> 
							</tr>
							<tr> 
								<th scope="row"> <code>Price</code> </th> 
								<td><?php echo $row['price']; ?></td> 
							</tr> 
							<tr> 
								<th scope="row"> <code>Stock</code> </th> 
								<td><?php echo $row['quantity']; ?></td> 
							</tr>
						</tbody> 
			    	</table> 
			    </div>
			    <div class="row text-center">
			    	<button class="btn btn-danger" onclick="location.href='../catalog/reviews.php?book_id=<?php echo $row['isbn']; ?>'">Reviews</button>
			    	<button class="btn btn-success" onclick="addToCart('<?php echo $row['isbn']; ?>');">Buy for <?php echo $row['price']; ?></button>
			    </div>
			  </div>
			</div>
		</div>
	<?php
		}
		if ($books->num_rows == 0)
			echo "<h4>&emsp;&emsp;&emsp;&emsp;Sorry, No Results Found</h4>";
	?>
	</div>
</div>
<div id="temp" style="display:none;"></div>
<script type="text/javascript">
	function addToCart (isbn) {
		var addtocart = "addtocart";
		$.ajax({
		           type: "POST",
		           url: "../catalog/cart.php",
		           data:{
		           		isbn:isbn,
		           		addtocart:addtocart
		           },
		           cache: false,
		           success: function(data)
		           {
		               $("#cart-count").html(parseInt($("#cart-count").html()) + 1);
						$("#cart-added-conf").modal('show');
		                
		           },    
		           error: function(jqXHR, textStatus, errorThrown)
		           {
		               alert("error" + jqXHR + textStatus + errorThrown);
		           }

		       });
	}
</script>
<?php include "../catalog/footer.php"; ?>
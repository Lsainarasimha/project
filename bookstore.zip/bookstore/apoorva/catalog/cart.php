<?php
	session_start();
	if (isset($_POST['addtocart']))
		addToCart();
	if (isset($_GET['removefromcart']))
		removeFromCart();
	if (isset($_GET['rebuild']))
		reBuild();
	function addToCart()
	{
		if(isset($_SESSION['cart-items']))
		{
			if (isset($_SESSION['cart-items'][''.$_POST['isbn'].'']))
			{
				$_SESSION['cart-items'][''.$_POST['isbn'].''] = $_SESSION['cart-items'][$_POST['isbn']] + 1;
			}
			else 
			{
				$_SESSION['cart-items']["".$_POST['isbn'].""] = 1;
			}
		}
		else 
			$_SESSION['cart-items']["".$_POST['isbn'].""] = 1;
	}
	function removeFromCart()
	{
		if (isset($_SESSION['cart-items'][''.$_GET['isbn'].'']))
		{
			unset($_SESSION['cart-items'][''.$_GET['isbn'].'']);
		}
	}
	function reBuild()
	{
		if (isset($_SESSION['cart-items'][''.$_GET['isbn'].'']))
		{
			$_SESSION['cart-items'][''.$_GET['isbn'].''] = $_GET['quantity'];
		}
	}
?>
<?php

$link = mysqli_connect("localhost","root","","readme");
if(mysqli_connect_errno()){
            print "connect failed:".mysqli_connect_error();
            exit();
        }

		else
{
	$cartisbn=$_POST['cartisbn'];
	$uusername=$_POST['username'];
	$newpin = $_POST['new_pin'];
	$address = $_POST['address'];
	$ccity = $_POST['city'];
	//$sstate = $_POST['state'];
	$zzip = $_POST['zip'];
	$ffname = $_POST['firstname'];
	$lastname = $_POST['lastname'];
	$cccno = $_POST['card_number'];
	$cardtype = $_POST['card_number'];
	$expirationdate = $_POST['expiration_date'];
	
	$query2 = "UPDATE customer SET 
			   pin='".$newpin."', street='".$address."', city='".$ccity."',zip='".$zzip."',firstname='".$ffname."',
			   lastname='".$lastname."', ccno='".$cccno."', ccexpdt='".$expirationdate."', cctype='".$cardtype."' 
			  where username ='".$uusername."'";
	$result= mysqli_query($link,$query2);
	if ( false===$result ) {
	  printf("error: %s\n", mysqli_error($link));
	}
	else {
	  		echo "<script>
				var books='$cartisbn';
				window.location.href='confirmorder.php?cartisbn='+ books;
				</script>";
	}
    //$row2 = mysqli_fetch_assoc($result2);
}
?>
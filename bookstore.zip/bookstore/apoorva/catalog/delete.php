<!DOCTYPE HTML>
<html>
<head>
	<title>Shopping Cart1</title>
	<?php
		session_start();
		if(isset($_GET['cartisbn']))
			$cartisbn= $_GET['cartisbn'];
		else
			$cartisbn="";
		if(isset($_GET['isbn']))
		{	
			$delisbn= $_GET['isbn'];
		}
		$cartisbn=trim($cartisbn,":");
		$arrayisbn = explode(":", $cartisbn);
		$key= array_keys($arrayisbn,$delisbn);
		for ($i=count($key)-1;$i>=0;$i--)
		{
			//echo $i." ".$key[$i];
			$currentkey=$key[$i];
			array_splice($arrayisbn,$currentkey,1);
		}
		$isbnarr = implode(":", $arrayisbn);
		//echo "isbn:".$delisbn;
    ?>
	<script>
		var books='<?= $isbnarr ?>';
		window.location.href="manage.php?cartisbn="+ books;
	</script>
</head>
<body background="image1.jpg"></body>
</html>
<?php include "../catalog/header.php"; ?>
<div class="container">
	<h2>Reviews</h2>
	<div class="row">
	<?php
		$sql_ext = "";
		if (isset($_GET['book_id']))
			$sql_ext = "WHERE isbn = '".$_GET['book_id']."'";
		$sql = "SELECT * FROM book ".$sql_ext." ORDER BY title ASC";
		$books = $db->query($db_connect, $sql);
		while ($row = $books->fetch_assoc()){
	?>
			<div class="col-md-4">

			<ul class="list-group">
			  <li class="list-group-item list-group-item-primary text-center"><span class="label label-primary label-custom"><?php echo $row['title']; ?></span></li>
			  <?php
			  	$sql = "SELECT * FROM bookreview WHERE isbn = '".$row['isbn']."'  ORDER BY review ASC";
			  	$reviews = $db->query($db_connect, $sql);
			  	$color_array = array("info", "success", "warning", "danger");
			  	while ($row1 = $reviews->fetch_assoc()){
			  ?>
			  <li class="list-group-item list-group-item-<?php echo $color_array[rand(0, count($color_array))]; ?>"><?php echo $row1['review']; ?></li>
			  <?php } 
			  	if ($reviews->num_rows == 0)
			  		echo "<li class=\"list-group-item list-group-item-primary\">No reviews..</li>"
			  ?>
			  <li class="list-group-item list-group-item-primary text-center"><button onclick="addToCart('<?php echo $row['isbn']; ?>');" class="btn btn-success">Buy for <?php echo $row['price']; ?></button></li>
			</ul>
				
			</div>
	<?php
		}
	?>
	</div>
</div>
<div id="temp" style="display:none;"></div>
<script type="text/javascript">
	function addToCart (isbn) {
		$("#temp").load('../catalog/cart.php?isbn='+isbn+'&addtocart=addtocart',function(){
			$("#cart-count").html(parseInt($("#cart-count").html()) + 1);
			$("#cart-added-conf").modal('show');
		});
	}
</script>
<?php include "../catalog/footer.php"; ?>
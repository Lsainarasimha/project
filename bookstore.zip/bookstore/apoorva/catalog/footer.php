</body>
<script type="text/javascript" src="../assets/jquery_latest.js"></script>
<script type="text/javascript" src="../assets/js/bootstrap.min.js"></script>
</html>
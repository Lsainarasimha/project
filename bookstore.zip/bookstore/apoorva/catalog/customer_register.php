<?php include "../catalog/header.php"; 
    if (isset($_POST['register']))
    {
        $firstname       = $_POST['firstname'];
        $lastname        = $_POST['lastname'];
        $username        = $_POST['username'];
        $password        = $_POST['password'];
        $address         = $_POST['address'];
        $city            = $_POST['city'];
        $state           = $_POST['state'];
        $zip             = $_POST['zip'];
        $card_type       = $_POST['card_type'];
        $card_number     = $_POST['card_number'];
        $expiration_date = $_POST['expiration_date'];
        $sql = "INSERT INTO customer (firstname,lastname,username,pin,street,city,state,zip,cctype,ccno,ccexpdt) VALUES ('".$firstname."','".$lastname."','".$username."','".md5($password)."','".$address."','".$city."','".$state."','".$zip."','".$card_type."','".$card_number."','".$expiration_date."')";
        $result = $db->query($db_connect, $sql);
    }

?>
<div class="container">
    <h2>Registration Form</h2>
    <div class="row">
        <form class="form-horizontal" method="POST">
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">First Name</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="firstname" name="firstname" placeholder="First Name">
                </div>
            </div>
            <div class="form-group">
                <label for="inputPassword3" class="col-sm-2 control-label">Last Name</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="lastname" name="lastname" placeholder="Last Name">
                </div>
            </div>
            <div class="form-group">
                <label for="inputPassword3" class="col-sm-2 control-label">Username</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="username" name="username" placeholder="Username">
                </div>
            </div>
            <div class="form-group">
                <label for="inputPassword3" class="col-sm-2 control-label">Password</label>
                <div class="col-sm-10">
                    <input type="password" class="form-control" id="password" name="password" placeholder="Password">
                </div>
            </div>
            <div class="form-group">
                <label for="inputPassword3" class="col-sm-2 control-label">Repeat Password</label>
                <div class="col-sm-10">
                    <input type="password" class="form-control" id="repeat-password" name="repeat-password" placeholder="Repeat Password">
                </div>
            </div>
            <div class="form-group">
                <label for="inputPassword3" class="col-sm-2 control-label">Address</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="address" name="address" placeholder="Address">
                </div>
            </div>
            <div class="form-group">
                <label for="inputPassword3" class="col-sm-2 control-label">city</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="city" name="city" placeholder="city">
                </div>
            </div>
            <div class="form-group">
                <label for="inputPassword3" class="col-sm-2 control-label">state</label>
                <div class="col-sm-10">
                    <select id="state" name="state" class="form-control">
                        <option value=""> Select State</option>
                        <option value="MICHIGAN">MICHIGAN</option>
                        <option value="CALIFORNIA">CALIFORNIA</option>
                        <option value="NEW YORK">NEW YORK</option>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label for="inputPassword3" class="col-sm-2 control-label">Zip</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="zip" name="zip" placeholder="zip">
                </div>
            </div>
            <h3>Credit Card Details</h3>
            <div class="form-group">
                <label for="inputPassword3" class="col-sm-2 control-label">Credit Card</label>
                <div class="col-sm-10">
                    <select id="card_type" name="card_type" class="form-control">
                        <option value=""> Select Card Type</option>
                        <option value="VISA">VISA</option>
                        <option value="DISCOVER">DISCOVER</option>
                        <option value="MASTER">MASTER</option>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label for="inputPassword3" class="col-sm-2 control-label">Credit Card Number</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="card_number" name="card_number" placeholder="Credit Card Number">
                </div>
            </div>
            <div class="form-group">
                <label for="inputPassword3" class="col-sm-2 control-label">Expiration Date</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="expiration_date" name="expiration_date" placeholder="Expiration Date (MM/YY)">
                </div>
            </div>
            <div class="form-group">
                <div class="col-sm-offset-2 col-sm-10">
                    <button "locaton.href='../catalog/admin_home.php'" type="button" class="btn btn-success pull-right">Cancel</button>
                    <button onclick="locaton.href='../catalog/admin_home.php'" type="submit" name="register" class="btn btn-danger pull-right" style="margin-right:5px;">Add Me</button>
                </div>
            </div>
        </form>
    </div>
</div>
<script type="text/javascript">
  function addToCart (isbn) {
    $("#temp").load('../catalog/cart.php?isbn='+isbn+'&addtocart=addtocart',function(){
      $("#cart-count").html(parseInt($("#cart-count").html()) + 1);
      $("#cart-added-conf").modal('show');
    });
  }
</script>
<?php include "../catalog/footer.php"; ?>
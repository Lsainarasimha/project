<!DOCTYPE HTML>
		<head>
		<title>Proof of purchase</title> 
		<?php
		session_start();
		$db = mysqli_connect("localhost","root","","readme");
		
        if(mysqli_connect_errno())
		{
            print "connect failed:".mysqli_connect_error();
            exit();
        }
		if(isset($_GET['cartisbn']))
		{	
			$cartisbn= $_GET['cartisbn'];
		}
		else
		{	
			$cartisbn="";				
		}
		$cartisbn=trim($cartisbn,":");
		$arrayisbn = explode(":", $cartisbn);
		$bookbuffer=array();
		$count=array();
		$counter=0;
		foreach($arrayisbn as $x)
		{
			$key=array_search($x,$bookbuffer);
			//echo "key".$key;
			if($key!==false)
			{	
				$count[$x]=$count[$x]+1;
				//echo "found";
			}
			else
			{	
				array_push($bookbuffer,$x);
				$count[$x]=1;
				$counter=$counter+1;
				//echo "not found";
			}						
		}
		$isbn = implode(",", $arrayisbn);
		$num_rows = $counter;
		
		if(isset($_SESSION['username']))
			$username= $_SESSION['username'];
		else
			$username="";	
		?>
		<script>
			books='<?= $cartisbn ?>';
			function search(books)
			{
				window.location.href="screen2.php?cartisbn="+books;
			}
			function update(books)
			{
				window.location.href="update.php?cartisbn="+books;
			}
		</script>
	</head>
	<body>
		<table align="center" style="border:2px solid blue;">

		<?php
		if($cartisbn!="")
		{
			echo "<tr><td colspan='4' align='center'><b>Confirm Order:</b></td></tr>
					<form id='buy' action='' method='post'>
					<tr><td><b>Shipping Address:</b></td></tr>";
			if(isset($_POST['buyit']))
			{
				if($_POST['cardgroup']=='new_card')
				{
					$ccno=(int)$_POST['card_number'];
					$cctype=$_POST['credit_card'];
					$ccexp=$_POST['card_expiration'];
					$query="UPDATE customer SET ccno=$ccno,cctype='$cctype',ccexpdt='$ccexp' where username=\"$username\";";
					//echo "<script>alert('".$query."');</script>";
					$result=  mysqli_query($db, $query);
					if(!$result)
					{
						print "Error- the query could not be executed".mysqli_error($db);
						exit();
					}	
					if(mysqli_affected_rows($db))
					{  
						$message ="Updated Credit Card details successfully";
						echo "<script type='text/javascript'>alert('$message');</script>";
					}
				}
				date_default_timezone_set('US/Eastern');
				$today = date("m/d/y");
				$timenow = date("H:i:s");
				$day = date("d");
				$month = date("m");
				$year = date("Y");
				$total=$_SESSION['total'];
				
				$query="INSERT INTO custorder values($day,$month,$year,'$timenow',$total,'$username');";
				for($ct=0;$ct<count($arrayisbn);$ct++)
				{
					$bk=$arrayisbn[$ct];
					//echo "<script type='text/javascript'>alert('$bk');</script>";
					//echo "<script type='text/javascript'>alert('$count[$bk]');</script>";
					$query1="INSERT INTO order_quantity values($day,$month,$year,'$timenow','$bk','$count[$bk]');";
				}
				echo "<script>alert('".$query."');</script>";
				echo "<script>alert('".$query1."');</script>";
				$result=  mysqli_query($db, $query);
				if(!$result)
				{
					print "Error- the query could not be executed".mysqli_error($db);
					exit();
				}	
				if(mysqli_affected_rows($db))
				{  
					$result1=  mysqli_query($db, $query1);
					if(!$result1)
					{
						print "Error- the query could not be executed".mysqli_error($db);
						exit();
					}
					if(mysqli_affected_rows($db))
					{
						echo "<script>var books='$cartisbn';
						window.location.href='Proofpurchase.php?cartisbn='+ books;</script>";
						
					}
				}

			}
			else
			{
				$query="SELECT * FROM customer where username='".$username."';";
				//echo $query;
				$result=  mysqli_query($db, $query);
				if(!$result)
				{
					print "Error- the query could not be executed".mysqli_error();
					exit();
				}
				$num_rows = mysqli_num_rows($result);
				if ($num_rows>0)
				{
					$totprice=0;
					$bookcount=0;
					$row= mysqli_fetch_assoc($result);
					$values = array_values($row);
					echo"<td colspan='2'>$values[6] $values[7]</td>";
					echo"<td rowspan='3' colspan='2'>
							<input type='radio' name='cardgroup' value='profile_card' checked>Use Credit card on file<br />$values[9]-$values[8]<br />
							<input type='radio' name='cardgroup' value='new_card'>New Credit Card<br />
									<select id='credit_card' name='credit_card'>
										<option selected disabled>select a card type</option>
										<option>VISA</option>
										<option>MASTER</option>
										<option>DISCOVER</option>
									</select>
							<input type='text' id='card_number' name='card_number' placeholder='Credit card number'>
							<br />Exp date<input type='text' id='card_expiration' name='card_expiration' placeholder='mm/yy'>
						</td>";
					echo"<tr><td colspan='2'>$values[2]</td></tr>
						<tr><td colspan='2'>$values[3]</td></tr>
						<tr><td colspan='2'>$values[4] $values[5]</td></tr>";

					if($isbn=="")
						$query="SELECT * FROM book where ISBN='".$isbn."';";
					else
						$query="SELECT * FROM book where ISBN in (".$isbn.");";
					//echo $query;
					$result=  mysqli_query($db, $query);
					if(!$result)
					{
						print "Error- the query could not be executed".mysqli_error();
						exit();
					}
					$num_rows = mysqli_num_rows($result);
					if ($num_rows>0)
					{
						
						print"<tr><td colspan='3' align='center'>
						<div id='bookdetails' style='overflow:scroll;height:180px;width:520px;border:1px solid black;'>
							<table border='1'style='width:500px;'>
								<th>Book Description</th><th>Qty</th><th>Price</th>";

						$row= mysqli_fetch_assoc($result);
						for($row_num = 1; $row_num <= $num_rows;$row_num++)
						{               
							$values = array_values($row);
							for ($index=0; $index<7; $index++)
							{						
								$value[$index] = htmlspecialchars($values[$index]);
							}
							$totprice=(float)$totprice+(float)($value[4]*$count[$value[0]]);
							$bookcount=$bookcount+$count[$value[0]];
							print "<tr><td>$value[1]</br><b>By</b>$value[2]</br><b>Price:</b>$value[4]</td>";
							print "<td>".$count[$value[0]]."</td>";
							print "<td>".$value[4]*$count[$value[0]]."</td></tr>";
							$row=  mysqli_fetch_assoc($result);
						}							
						 print "</table></div></td></tr>";
						 
					}
					else
					{
						print "<center><b>Cart is Empty</b></center>";
					}
					$shipping_handling=$bookcount*2.00;
					$total=(float)$totprice+(float)$shipping_handling;
					echo"<tr>
						<td align='left' colspan='2'>
						<div id='bookdetails' style='overflow:scroll;height:180px;width:260px;border:1px solid black;background-color:LightBlue'>
							<b>Shipping Note:</b> The book will be </br>delivered within 5</br>business days.
						</div>
						</td>
						<td align='right'>
						<div id='bookdetails' style='overflow:scroll;height:180px;width:260px;border:1px solid black;'>
								SubTotal:$totprice</br>Shipping_Handling:$shipping_handling</br>_______</br>Total:$total	
						</div>
						</td>
						</tr>";
					$_SESSION['total']=$total;
					echo"<tr>
						<td align='right'>
							<input type='submit' id='buyit' name='buyit' value='BUY IT!'>
						</td>
						</form>
						<td align='right'>
							<form action=\"JavaScript:update('$cartisbn')\" method='post'>
								<input type='submit' id='update_customerprofile' name='update_customerprofile' value='Update Customer Profile'>
							</form>
						</td>";
				}
			}
		}
		else
		{
			print "<center><b>Nothing to Purchase</b></center>";
		}
			?>

				<td align="left">
					<?php echo"<form action=\"JavaScript:search('$cartisbn')\" method='post'>";?>
						<input type="submit" id="cancel" name="cancel" value="Cancel">
					</form>
				</td>
			</tr>
		</table>
	</body>
</HTML>
<!DOCTYPE HTML>

<?php
session_start();
$link = mysqli_connect("localhost","root","","readme");

mysqli_error($link);
/* check connection */
if (mysqli_connect_errno()) 
{
    printf("Connect failed: %s\n", mysqli_connect_error());
    exit();
}
		if(isset($_GET['cartisbn']))
		{	
			$cartisbn= $_GET['cartisbn'];
		}
		else
		{	
			$cartisbn="";				
		}
?>

<?php
$username= $_SESSION['username'];
$query1="select * from customer where username='$username'";
$result1= mysqli_query($link,$query1);
$row = mysqli_fetch_assoc($result1);
	echo "
	<head>
	<title>UPDATE CUSTOMER PROFILE</title>
</head>
<body background="image1.jpg">
	

    /* Get field information for all columns */
		<form id='update_profile' action='update1.php' method='post'>
		<input type = 'hidden' id='cartisbn' name='cartisbn' value='$cartisbn' />
			<table align='center' style='border:2px solid blue;'>
				<tr>
				
					<td align='right'>
						Username :<span style='color:red'></span>
					</td>
					<td>
					<input type='hidden' id='username' name='username' value='".$row['username']."'/>
					<label>".$row['username']."
					</td>
					<td colspan='3''align='center'>
					</td>
				</tr>
				<tr>
					<td align='right'>
						New PIN<span style='color:red'>*</span>
					</td>
					<td>
					<input type='text' id='pin' name='new_pin' value='".$row['pin']."'/>
					</td>
				</tr>
				
				<tr>
					<td align='right'>
						Address<span style='color:red'>*</span>
					</td>
					<td colspan='3'>
						<input type='text' id='address' name='address' value='".$row['street']."'/>
					</td>
				</tr>
				<tr>
					<td align='right'>
						City<span style='color:red'>*</span>
					</td>
					<td colspan='3'>
						<input type='text' id='city' name='city' value='".$row['city']."'/>
					</td>
				</tr>
				<tr>
					<td align='right'>
						State<span style='color:red'>*</span>
					</td>
					<td>
						<select id='state' name='state' value='".$row['state']."'/>
						<option selected disabled>select a state</option>
						<option value='Michigan'>Michigan</option>
						<option value='California'>California</option>
						<option value='Tennessee'>Tennessee</option>
						</select>
					</td>
					<td align='right'>
						Zip<span style='color:red'>*</span>
					</td>
					<td>
						<input type='text' id='zip' name='zip' value='".$row['zip']."'/>
					</td>
				</tr>
				<tr>
					<td align='right'>
						First Name<span style='color:red'>*</span>
					</td>
					<td colspan='3'>
						<input type='text' id='firstname' name='firstname' value='".$row['firstname']."'/>
					</td>
				</tr>
				<tr>
					<td align='right'> 
						Last Name<span style='color:red'>*</span>
					</td>
					<td colspan='3'>
						<input type='text' id='lastname' name='lastname' value='".$row['lastname']."'/>
					</td>
				</tr>
				<tr>
					<td align='right'>
						Credit Card<span style='color:red'>*</span>:
					</td>
					<td align='left' colspan='2'>
						<input type='text' id='card_number' name='card_number' placeholder='Credit card number' value='".$row['ccno']."'/>
					</td>
					<td>
						<select id='credit_card' name='credit_card' value='".$row['cctype']."'/>
						<option selected disabled>select a card type</option>
						<option value='visa'>VISA</option>
						<option value='mastercard'>MASTER</option>
						<option value='american express'>DISCOVER</option>
						</select>
					</td>
					
				</tr>
				<tr>
					<td align='right' colspan='2'>
						Expiration Date<span style='color:red'>*</span>:
					</td>
					<td colspan='2' align='left'>
						<input type='text' id='expiration_date' name='expiration_date' value='".$row['ccexpdt']."' placeholder='MM/YY'/>
					</td>
				</tr>
				<tr>
					<td align='right' colspan='2'>
						<input type='submit' id='update_submit' name='update_submit' value='Update'>
					</td>
					</form>
					<form id='cancel' action='' method='post'>	
					<td align='left' colspan='2'>
						<input type='submit' id='cancel_submit' name='cancel_submit' value='Cancel'>
					</td>
					</form>
				</tr>
			</table>
		
	</body>
</html>";
	
  ?>
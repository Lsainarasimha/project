<?php
	header("Expires: Thu, 19 Nov 1981 08:52:00 GMT"); //Date in the past
	header("Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0"); //HTTP/1.1
	header("Pragma: no-cache");
	require_once("../common/Database.php");
	$db = new Database;
	$db_connect = $db->connect();
?>
<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
	<!-- <link rel="icon" href="../favicon.ico" type="image/x-icon"> -->
	<link rel="stylesheet" href="../assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="../assets/css/custom.css">
</head>
<body onunload=""  background="../assets/image1.jpg">
<div claas="container">
	<nav class="navbar navbar-default">
	  <div class="container-fluid">
	    <!-- Brand and toggle get grouped for better mobile display -->
	    <div class="navbar-header">
	      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
	        <span class="sr-only">Toggle navigation</span>
	        <span class="icon-bar"></span>
	        <span class="icon-bar"></span>
	        <span class="icon-bar"></span>
	      </button>
	      <a class="navbar-brand" href="#"><img src="../assets/footer-logo.png" style="height:60px;width:auto;"></a>
	    </div>

	    <!-- Collect the nav links, forms, and other content for toggling -->
	    <div class="collapse navbar-collapse navbar-nav-custom" id="bs-example-navbar-collapse-1">
	      <ul class="nav navbar-nav">
	        <li ><a href="../catalog/customer_home.php">Home <span class="sr-only">(current)</span></a></li>
	        <!-- <li><a href="#">Categories</a></li> -->
	        <li><a href="../catalog/reviews.php">Reviews</a></li>
	      </ul>
	      <form class="navbar-form  navbar-form-custom navbar-left" method="GET" action="../catalog/search.php" role="search">
	        <div class="form-group">
	          <input type="text" name="search-word" id="search-word" class="form-control" placeholder="Search" value="<?php if (isset($_GET['search-word'])) echo $_GET['search-word']; ?>">
	        </div>
	        <button type="submit" class="btn btn-default"><span class="glyphicon glyphicon-search" aria-hidden="true"></span></button>
	      </form>
	      <ul class="nav navbar-nav navbar-right">
	      	<?php
      			if (isset($_SESSION['customer_username']))
      			{
      				echo "<li><a href=\"#\">Welcome ".$_SESSION['customer_username']."</a></li>";
      				echo "<li><a href=\"../catalog/account.php\">My Account</a></li>";
      				echo "<li><a href=\"../common/login.php?action=logout\">Logout</a></li>";
      			}
      			else
      			{
      				echo "<li><a href=\"../common/login.php\">Login</a></li>";
      				echo "<li><a href=\"../catalog/customer_register.php\">Register</a></li>";
      			}
      			$cart_count = 0;
      			if(isset($_SESSION['cart-items']))
      			{
      				foreach ($_SESSION['cart-items'] as $key => $value) {
      					$cart_count += $value;
      				}
      			}
	      	?>
	        <li><a href="../catalog/managecart.php">Cart <span class="badge" id="cart-count"><?php echo $cart_count; ?></span></a></li>
	      </ul>
	    </div><!-- /.navbar-collapse -->
	  </div><!-- /.container-fluid -->
	</nav>
</div>
<div class="modal fade" id="cart-added-conf" tabindex="-1" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title">Product Added Confirmation</h4>
      </div>
      <div class="modal-body">
        <p class="text-success">Product Added To Cart Sucessfully!</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary" onclick="location.href='../catalog/managecart.php'">Go To Cart</button>
        <button type="button" class="btn btn-success" onclick="location.href='../catalog/checkout.php'">Proceed To Checkout</button>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->


<?php include "../catalog/header.php"; ?>
<div class="container">
	<h2>My Cart</h2>
	<div class="row">
	<?php  
	
		$counter = 0;
		if (isset($_SESSION['cart-items'])){
			foreach ($_SESSION['cart-items'] as $key => $value) {
				$counter++;
			}
		}
		if ($counter != 0) {
	?>
		<div class="table-responsive">
		  <table class="table table-bordered">
		   		<thead>
		   			<tr>
		   			  <th>S.No</th>
		   			  <th>Name</th>
		   			  <th>Category</th>
		   			  <th>Author</th>
		   			  <th>Quantity</th>
		   			  <th>Unit Price</th>
		   			  <th>Total</th>
		   			</tr>
		   		</thead>
		   		<tbody>
		   			<?php 
		   				$counter = 1;
		   				$sub_total = 0;
		   				foreach ($_SESSION['cart-items'] as $key => $value) {
		   					$sql = "SELECT * FROM book WHERE isbn = '".$key."'";
							$books = $db->query($db_connect, $sql);
							$row = mysqli_fetch_assoc($books);
							echo "<tr><td>".$counter."</td>";
							echo "<td>".$row['title']."</td>";
							echo "<td>".$row['category']."</td>";
							echo "<td>".$row['author']."</td>";

							echo "<td><input type='number' style='width:50px;' id='rebuild_value_".$row['isbn']."' name='rebuild_value' value='".$value."'> X ";
							echo "&emsp;<button class='btn btn-success' type='button' onclick=\"reBuild('".$row['isbn']."'); \">Rebuild</button>";
							echo "&emsp;<button class='btn btn-danger' type='button' onclick=\"removeFromCart('".$row['isbn']."'); \"><span class=\"glyphicon glyphicon-trash\" aria-hidden=\"true\"></span></button>";
							echo "</td>";
							echo "<td>".$row['price']."</td>";
							$sub_total += $value  * $row['price'];
							echo "<td>";
							echo ($value  * $row['price']);
							echo "</td>";
							echo "</tr>";
		   					$counter++;
		   				}
		   				echo "<tr>";
		   				echo "<td class='text-right' colspan='6'>Sub - Total</td>";
		   				echo "<td class='text-left'>".$sub_total."</td>";
		   				echo "</tr>";
		   			?>
		   		</tbody>
		  </table>
		</div>
		<button class="btn btn-success pull-right" onclick="location.href='../catalog/checkout.php'">Proceed to checkout</button>
		<div id="temp" style="display:none;"></div>
	<?php
	}
	else
		echo "<h3><span class=\"glyphicon glyphicon-shopping-cart\" aria-hidden=\"true\"></span> &emsp;Cart Is Empty, Try New Arrivals.</h3>";

	?>
	</div>
</div>
<script type="text/javascript">
	 document.addEventListener('DOMContentLoaded', function(){
	 	$("body").attr('background','../assets/image2.jpg');
	 });

	function removeFromCart (isbn) {
		$("#temp").load('../catalog/cart.php?isbn='+isbn+'&removefromcart=removefromcart',function(){
			location.reload();
		});
	}
	function reBuild (isbn) {
		var quantity = $("#rebuild_value_"+isbn+"").val();
		$("#temp").load('../catalog/cart.php?isbn='+isbn+'&quantity='+quantity+'&rebuild=rebuild',function(){
			location.reload();
		});
	}

</script>
<?php include "../catalog/footer.php"; ?>
<?php
	header("Expires: Thu, 19 Nov 1981 08:52:00 GMT"); //Date in the past
	header("Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0"); //HTTP/1.1
	header("Pragma: no-cache");
	require_once("Database.php");
	$db = new Database;
	$db_connect = $db->connect();
						// Redirects to home page if there is any session available
	/*if (isset($_SESSION['session']))
	{
		if (isset($_SESSION['admin_username']))
			header("Location: ../admin/admin_home.php");
		else
			header("Location: ../catalog/customer_home.php");
	}*/
				// Checks for login form submission
	if(isset($_POST['login']))
	{
	  	$username 	= $_POST['username'];
	  	$pin 		= $_POST['password'];

	  	$query = "SELECT * FROM customer WHERE username = '".$username."' AND pin = '".md5($pin)."'";
	  	$customers = $db->query($db_connect, $query);
	  	if (mysqli_num_rows($customers) <= 0)
	  	{
	  		$query = "SELECT * FROM administrator WHERE username ='".$username."' AND pin ='".md5($pin)."'";
	  		$admins = $db->query($db_connect, $query);  
	  		if (mysqli_num_rows($admins) <= 0)
	  		{
	  			$message = "Incorrect Username or Password";
	  		}
	  		else
	  		{
	  			$_SESSION['admin_username'] = $username;
	  										// redirects to respective homes
	  			header("Location: ../admin/admin_home.php");
	  		}
	  	}
	  	else
	  	{
  			$_SESSION['customer_username'] = $username;
  			header("Location: ../catalog/customer_home.php");
	  	}
	}
	else if (isset($_GET['action']))
	{
		unset($_SESSION['customer_username']);
		header("Location: ../common/login.php");
	}
	else if (isset($_GET['admin_action']))
	{
		unset($_SESSION['admin_username']);
		header("Location: ../common/login.php");
	}

?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>:: Secure Login ::</title>
		<link rel="stylesheet" href="../assets/css/bootstrap.min.css">
		<link rel="stylesheet" href="../assets/css/custom.css">
	</head>
<body background="image3.jpg">
	<div class="container" style="width:500px;">

	      <form class="form-signin" action="login.php" method="post" id="login_form">
	        <h2 class="form-signin-heading">Please sign in</h2>
	        <label for="inputEmail" class="sr-only">Username</label>
	        <input type="text" id="username" name="username" class="form-control" placeholder="Username" required autofocus>
	        <br/>
	        <label for="inputPassword" class="sr-only">Password</label>
	        <input type="password" id="password" name="password" class="form-control" placeholder="Password" required>
	        <!-- <div class="checkbox">
	          <label>
	            <input type="checkbox" value="remember-me"> Remember me
	          </label>
	        </div> -->
	        <br/>
	        <button class="btn btn-lg btn-primary btn-block" type="submit" name="login">Sign in</button>
	        <button class="btn btn-lg btn-danger btn-block" type="button">cancel</button>
	      </form>

	    </div> <!-- /container -->
</body>
<script type="text/javascript" src="../assets/jquery_latest.js"></script>
<script type="text/javascript" src="../assets/js/bootstrap.min.js"></script>
</html>
<?php
	if (isset($message))
		echo "<script type='text/javascript'>alert('$message');</script>";
?>
